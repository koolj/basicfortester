﻿

function addBrowseTopicInSearchOptions(domainDdId, scolDdId, optionValue) {
    try {        
        var domainDropDown = document.getElementById(domainDdId);
        var scolDropDown = document.getElementById(scolDdId);
        //find browsetree already there in the options and get the index of the bookshelf
        var thisTopicExists = false;
        var optnBookshlef = null;
        var optnBookshlefIndex = 0;

        for (i = 0; i < domainDropDown.options.length; i++) {
            if (domainDropDown.options[i].value == "browsetree") {
                thisTopicExists = true;
                break;
            }
            if (domainDropDown.options[i].value == "bookshelf") {
                optnBookshlef = domainDropDown.options[i]; // for Non-IE
                optnBookshlefIndex = i; // for IE
            }
        }
        if (false == thisTopicExists) {

            if (null == optnBookshlef) {
                domainDropDown.add(createOptnThisTopic());
            }
            else {
                try {
                    domainDropDown.add(createOptnThisTopic(), optnBookshlef); // standards compliant; doesn't work in IE
                }
                catch (ex) {
                    domainDropDown.add(createOptnThisTopic(), optnBookshlefIndex); // IE only
                }
            }

            try {
                scolDropDown.add(createOptnThisTopic(optionValue), null); // standards compliant; doesn't work in IE
            }
            catch (ex) {
                scolDropDown.add(createOptnThisTopic(optionValue)); // IE only
            }
        }
    } catch (e) {
        var x = e;        
    }
}
function createOptnThisTopic(optionValue) {
    var optnThisTopic = document.createElement('option');
    optnThisTopic.text = "This Topic";
    // For search collection dropdown list
    if (optionValue) {
        optnThisTopic.value = optionValue;
    }
    // For domain dropdown list            
    else {
        optnThisTopic.value = "browsetree";
    }
    return optnThisTopic;
}
function toggleFilter(onoff, location) {
    try {
        var filterOff = document.getElementById("filterSelectClosed" + location);
        var filterOn = document.getElementById("filterSelectOpen" + location);
        var control = document.getElementById("FilterControlForm" + location);
        if (onoff == 0) {
            filterOff.style.display = "inline";
            filterOn.style.display = "none";
            control.style.display = "none";
        }
        else {
            filterOff.style.display = "none";
            filterOn.style.display = "inline";
            control.style.display = "";
        }
    } catch (e) { }
}

function showHideTab(tab) {
    var assetTab = document.getElementById("TitleTab");
    var peopleTab = document.getElementById("PeopleTab");
    assetTab.style.display = "none";
    peopleTab.style.display = "none";
    if (tab != "None") {
        document.getElementById(tab).style.display = "";
    }
}

function toggleResult(onoff) {
    try {
        var asset = document.getElementById("AssetViewDiv");
        var people = document.getElementById("PeopleViewDiv");
        var brosweTopicsTree = document.getElementById("browsetopicsdiv");
        
        if (onoff == 1) { //Show Asset and hide people
            // Asset related stuff
            asset.style.display = "";
            
            // People Related stuff
            people.style.display = "none";
            
            // show the Browse topics
            //brosweTopicsTree.style.display = "";            
        }
        else { // Hide Asset and show People
            // People related stuff
            people.style.display = "";
            
            // Asset related stuff
            asset.style.display = "none";
            
            // Hide the Browse topics
            //brosweTopicsTree.style.display = "none";            
        }
    } catch (e) {
    var x = e;
    }
}