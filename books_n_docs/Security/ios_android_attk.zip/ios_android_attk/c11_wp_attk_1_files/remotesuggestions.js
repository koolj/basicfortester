var b24Suggestions = new Array();  // this has to be outside the object since it's used in the httprequest onreadystatechange function

/**
 * Provides suggestions from b24 search history
 * @class
 * @scope public
 */
function RemoteStateSuggestions() {
    this.searchDomainSelect = document.getElementById("qdom");
    this.searchDomainValue = "all";
    var grub = null;
    if (this.searchDomainSelect == null) {
        grub = document.getElementsByTagName("select");
        for (var i = 0; i < grub.length; i++)  {
            var selid = grub[i].getAttribute("id");
            if (selid.indexOf("_qdom") > -1)   {
                this.searchDomainSelect=grub[i];
                break;
            }
        }
    }
    if (this.searchDomainSelect != null) {
        this.searchDomainValue = this.searchDomainSelect.value;
    }
    this.searchCollectionSelect = document.getElementById("scol");
    this.searchCollectionValue = "all,";
    if (this.searchCollectionSelect == null) {
        if (grub == null) {
            grub = document.getElementsByTagName("select");
        }
        for (var i = 0; i < grub.length; i++)  {
            var selid = grub[i].getAttribute("id");
            if (selid.indexOf("_scol") > -1)   {
                this.searchCollectionSelect=grub[i];
                break;
            }
        }
    }
    if (this.searchCollectionSelect != null) {
        this.searchCollectionValue = this.searchCollectionSelect.value;
    }
    b24Suggestions = new Array();
    this.http = XMLHttpRequestObject;

}

/**
 * Request suggestions for the given autosuggest control. 
 * @scope protected
 * @param oAutoSuggestControl The autosuggest control to provide suggestions for.
 */
RemoteStateSuggestions.prototype.requestSuggestions = function (oAutoSuggestControl /*:AutoSuggestControl*/,
                                                          bTypeAhead /*:boolean*/) {

    if (this.http == null) {
      return;
    }
    var domainField = "all";
    var collection = "all,";
    if (this.searchDomainSelect != null) {
        domainField = this.searchDomainSelect.value;
    }
    if (this.searchDomainValue != domainField) {
        b24Suggestions = new Array();
        this.searchDomainValue = domainField;
    }
    if (this.searchCollectionSelect != null) {
        collection = this.searchCollectionSelect.value;
    }
    if (this.searchCollectionValue != collection) {
        b24Suggestions = new Array();
        this.searchCollectionValue = collection;
    }
    if (domainField == "ingenProfile" ||
        domainField.indexOf("bookmarks") > -1)
    {
        return;
    }
    var suggestions = b24Suggestions[oAutoSuggestControl.textbox.value.toLowerCase()];
    if (suggestions != null) {
        oAutoSuggestControl.autosuggest(suggestions.split('|'), bTypeAhead);                
    }
    else {
      this.searchDomainValue = domainField;
      var oHttp = this.http;  
      //if there is already a live request, cancel it
      if (oHttp.readyState != 0) {
          oHttp.abort();
      } 
      var splitchar = '~';    
      //build the URL
      var sURL = "progressive.asp?svc=progressivesuggest&data=" + encodeURIComponent(oAutoSuggestControl.textbox.value);
      if (domainField != null) {
          sURL += "&data=" + domainField;
      }
      if (collection != null && collection.indexOf(',') == -1) {
          sURL += "&data=" + collection;
      }
      
      //open connection to states.txt file
      oHttp.open("get", sURL , true);
      oHttp.onreadystatechange = function () {
          if (oHttp.readyState == 4) {
            var aSuggestions = oHttp.responseText;
            if (aSuggestions != null && aSuggestions.length > 0) {
              //evaluate the returned text JavaScript (an array)
              //provide suggestions to the control
              var response = aSuggestions.split(splitchar);
              for (var i = 0; i < response.length; i++) {
                /*
                var entries = response[i].split('|');
                var fixed = "";
                for (var j = 1; j < entries.length; j++) {
                    var entry = entries[j].split('/');
                    fixed += entry[0] + '|';
                }
                b24Suggestions[entries[0].toLowerCase()] = fixed;
                */
                var where = response[i].indexOf('|');
                if (where == -1) {
                    b24Suggestions[response[i].toLowerCase()] = response[i];
                }
                else {
                    b24Suggestions[response[i].substring(0,where).toLowerCase()] = response[i].substring(where + 1);
                }
              }
              var suggestions = b24Suggestions[oAutoSuggestControl.textbox.value.toLowerCase()];
              if (suggestions != null) {
                oAutoSuggestControl.autosuggest(suggestions.split('|'), bTypeAhead);                
              }    
            }
          }     
      };
      oHttp.send(null);
  }

};
