// --- some strings for translation
/*
var YourCommentGoesHere = "Your comment goes here";
var DeletingANote = "Deleting a note or comment permanently removes it.  If comments have been applied to it, it will remain as an empty placeholder.";
var DoYouWishToDeleteThis = "Do you wish to delete this?";
var FlaggingNotesAndComments = "Flagging notes and comments as inappropriate removes the text from view for everyone in your community. Each report will be reviewed by your system administrator for a final decision.";
var DoYouWishToFlagAsInappropriate = "Do you wish to flag this item as inappropriate?";
var InOrderToAddYourComment = "In order to add your Comment, you must first join the inGenius community.  Please click <a href='myprofile.aspx?mode=1' target='_parent'>here</a> to create and publish your profile. ";
var NewTwistieNotes = "Notes";
var PleaseConfirmThisAction = "Please confirm this action:";
var ConfirmYes = "Yes";
var ConfirmNo = "No";
var ConfirmClose = "Click here to close";
*/
var bookmarkcreatelabel = 'Create a note';
var bookmarkeditlabel = 'Edit note'; 
var bookmarkdeletelabel = 'Delete note'; 
var commentcreatelabel = 'Create New Comment'; 
var commenteditlabel = 'Edit Comment'; 
var commentdeletelabel = 'Delete Comment'; 
var commentempty1msg = 'There are currently no comments on this book.'; 
var commentempty2msg = 'You must be logged-in to view or create comments.'; 
var notecreatedlabel = 'Created:'; 
var notefromlabel = 'from'; 
var createlabel = 'Create'; 
var nosynopsismsg = 'There is no synopsis available for this title.'; 
var nobookaccessmsg = 'You currently do not have access to this book.'; 
var bookpreviewonlymsg = 'You currently only have access to this book in Preview Mode.'; var archivelabel = 'Archive'; var hascompanionwebsitelabel = 'Has Companion Web Site'; var companionwebsitelabel = 'Companion Web Site'; var printerfriendlylabel = 'Printer friendly format'; var suggestrplabel = 'Suggest a ReferencePoint'; var addedtobookshelflabel = 'Added to My Bookshelf on'; var bookmarkslabel = 'Bookmarks'; var colleaguecommentslabel = 'Colleague Comments'; var publiccommentslabel = 'Public Comments'; var byauthorlabel = 'by'; var andauthorlabel = 'and'; var etalauthorlabel = 'et al.'; var pageslabel = 'pages'; var synopsislabel = 'Synopsis'; var booksummarylabel = 'A Summary'; var bookblueprintlabel = 'A Blueprint'; var CDContentLabel = 'CD Content'; var RemoveBookFromBookshelf = 'Remove book from bookshelf'; var searchresultslabel = 'Search Results'; var lastaccessedlabel = 'Accessed'; var todaylabel = 'today'; var bookreportlabel = 'A Report'; var bookauthorlabel = 'book author:'; var bookauthorslabel = 'book authors:'; var backcoverlabel = 'Back Cover'; var bookcovertooltip = 'The Coverimage'; var nobooksmsg = ''; var nobooksbookshelfmsg = 'There are currently no books on your bookshelf.'; var bookbinlabel = 'Books: '; var morelabel = 'More...'; var tophitslabel = 'Top Section Hits'; var oflabel = 'of'; var inthisbooklabel = 'in this book'; var relevantchapterslabel = 'Relevant Chapters'; var inthelabel = 'in the'; var tableofcontentslabel = 'Table of Contents'; var BookListLabel = 'Book List'; var collectionslabel = 'Collections'; var NoAccessCollectionLabel = 'No access in collection'; var emptytopicsmsg = 'No topics found.'; var topicslabel = 'Topics:'; var topiclabel = 'Topic:'; var subtopicslabel = 'Subtopics:'; var subtopiclabel = 'Subtopic:'; var relatedtopicslabel = 'Related Topics'; var booksfoundlabel = 'books found'; var TopicListLabel = 'Topic List'; var pdflabel = 'download available'; var pdfdownloadlabel = 'PDF Files for Download'; var pdfdownloadlinklabel = 'Download Now'; var pdffiledesclabel = 'File Description'; var pdfcostlabel = 'Cost'; var pdffreelabel = 'Free'; var pdfcopyrightmsg = 'All rights reserved. Reproduction and/or distribution in whole or in part in electronic, paper or other forms without written permission is prohibited.'; var pdfnocopylabel = 'Copying Prohibited'; var pdfreprintedforlabel = 'Reprinted for'; var pdfreprintbenefitlabel = 'Reprinted with permission as a subscription benefit of'; var pdfmoreinfolabel = 'For further information about'; var pdfvisitlabel = 'visit'; var pdforcalllabel = 'or call'; var pdfmp4streamlabel = 'MP4 Video Download'; var priceperuserlabel = 'per user'; var priceperseatlabel = 'per seat'; var priceotheroptionslabel = 'Additional Options:'; var pricetotallabel = 'Total Price:'; var pricenonelabel = 'Pricing unavailable at this time.'; var adminnamelabel = 'Administrator Name:'; var emailaddrlabel = 'E-Mail Address:'; var companynamelabel = 'Company Name:'; var substartslabel = 'Starts:'; var subexpireslabel = 'Expires:'; var subtypelabel = 'Type of Subscription:'; var subtype0 = 'Trial'; var subtype1 = 'Paid'; var subtype2 = 'Complementary'; var subtype3 = 'Internal'; var subrenewstatuslabel = 'Renewal Status:'; var subrenewoption0 = 'Unspecified'; var subrenewoption1 = 'Renew'; var subrenewoption2 = 'Do Not Renew'; var subrenewoption3 = 'Not Applicable'; var subrenewoption4 = 'Requires Action'; var substatuslabel = 'Status:'; var substatusoption1 = 'Active'; var substatusoption2 = 'Expired'; var substatusoption3 = 'Overdue'; var substatusoption4 = 'Disabled'; var seatcountlabel = 'Seat Count:'; var seatstotallabel = 'total seats'; var pricelabel = 'Price:'; var fullaccessoption0 = 'Preview'; var fullaccessoption1 = 'Yes'; var previewaccesslabel = 'Preview Access'; var fullaccesslabel = 'Full Access'; var noaccesslabel = 'NO Access'; var renewalinfolabel = 'Info'; var renewalupgradelabel = 'Upgrade'; var renewalstatusunknownlabel = 'Unknown'; var IngeniousBanner = 'Share your Notes, Comments and more.  Join the  inGenius  Community today.'; var IngeniousBannerLink = 'Complete your Profile.'; var IngeniousProfileLabel = 'Edit your inGenius Community Profile'; var bookmarklistitle = ''; var notepubliclabel = 'Community'; var noteprivatelabel = 'Private'; 
var YourCommentGoesHere = 'Your comment goes here'; 
var DeletingANote = 'Deleting a note or comment permanently removes it.  If comments have been applied to it, it will remain as an empty placeholder.'; 
var DoYouWishToDeleteThis = 'Do you wish to delete this?'; 
var FlaggingNotesAndComments = 'Flagging notes and comments as inappropriate removes the text from view for everyone in your community. Each report will be reviewed by your system administrator for a final decision.'; 
var DoYouWishToFlagAsInappropriate = 'Do you wish to flag this item as inappropriate?'; 
var InOrderToAddYourCommentBefore = 'In order to add your Comment, you must first join the inGenius community.  Please click ';
var InOrderToAddYourCommentLink = 'here';
var InOrderToAddYourCommentAfter = ' to create and publish your profile.'; 
var NewTwistieNotes = 'Notes'; 
var PleaseConfirmThisAction = 'Please confirm this action:'; 
var ConfirmYes = 'Yes'; 
var ConfirmNo = 'No'; 
var ConfirmClose = 'Click here to close'; 
var NotesTitle = 'Notes'; 
var InappropriateText = 'Content was flagged as inappropriate'; 
var NoteDeletedText = 'This note has been deleted'; 
var NoteEdit = 'Edit'; 
var NoteDelete = 'Delete'; 
var NoteComment = 'Comment'; 
var NoteReportAbuse = 'Report Abuse'; 
var CommentNew = 'New comment'; 
var CommentUpdate = 'Update comment'; 
var CommentCancel = 'Cancel comment'; 
var CommentTitle = 'Comments'; 
var NotesCreated = 'Created'; 
var NotesModified = 'Created'; 
var NotesDaysAgo = 'days ago by'; 
var NotesMinutesAgo = 'minutes ago by'; 
var NotesHoursAgo = 'hours ago by'; 
var gotobooks24label = 'Go to Books24x7'; 
var gotohelplabel = 'Go to Help Page'; 
var exitlabel = 'Exit'; 
var purchasebooklabel = 'Purchase Book'; 
var addbookshelflabel = 'Add to My Favorites'; 
var removebookshelflabel = 'Remove from My Favorites'; 
var addmyplanlabel = 'Add to My Plan'; 
var removemyplanlabel = 'Remove from My Plan'; 
var downloadbookpdflabel = 'Download Book PDF';
var downloadchapterpdflabel = 'Download Chapter PDF'; var downloadbookaudiolabel = 'Download Audio'; var PreviousLabel = 'Previous'; var NextLabel = 'Next'; var chapcontentslabel = 'Chapter Contents'; var PreviousChapterLabel = 'Previous Chapter'; var NextChapterLabel = 'Next Chapter'; var PreviousSectionLabel = 'Previous Section'; var NextSectionLabel = 'Next Section'; var topofpagelabel = 'Top of page'; var searchformtitle = 'Search this book:'; var progressmeterlabel = 'Progress Indicator'; var backtotoclabel = 'Back to Table of Contents'; var backlabel = 'Back'; var golabel = 'Go';

var JoinPromptCommentThankyou = "Thank you for sharing your comment with the %companyname% Books24x7 community.";
var JoinPromptFollowThankyou = "Thank you for joining the %companyname% community by following someone in %companyname%.";
var JoinPromptRecommendContentItemThankyou = "Thank you for joining the %companyname% Books24x7 community.";
var JoinPromptBoilerPlate = "About inGenius:  Now you can find and share knowledge and expertise with others in the %companyname% organization. To enhance your profile or change privacy settings, go to your profile page.";
var JoinPromptProfileLink = "Edit Profile Privacy Settings";
var JoinPromptHelpLink = "Learn More about inGenius";
var JoinPromptRecommendBookThankyou = "Thank you for sharing your recommendation with the %companyname% Books24x7 community";
var JoinPromptNoteCreateThankyou = "Thank you for sharing your note with the %companyname% Books24x7 community";



/**
* given a comment block and a bookmarkid, set up the empty comment
*/    
function ArtifactInitializeEmptyComment(noteblock, bookmarkid)
{
    var comment = document.getElementById("new-comment-" + bookmarkid);
    if (comment == null) {
        return;   // we're dead
    }
    ArtifactInitializeCommentForm(comment, noteblock);
}
function ArtifactInitializeCommentForm(comment,noteblock) {
    comment.isBlankForm = true;
    if (!noteblock) {  // find our block container.  it has important information for us
        var parent = comment.parentNode;
        while (parent != null && (parent.LocationUri == null)) {
            parent = parent.parentNode;
        }
        if (parent != null) {
            noteblock = parent;
        }
    }
    var bookmarkid = comment.getAttribute("applyto");
    comment.bookmarkid = bookmarkid;
    comment.commentblock = noteblock;
    comment.noteblock = noteblock;
    comment.cancelComment = function() {     // give it a cancel function
        var blockid = "CommentSection-control-" + this.bookmarkid;
        var block = document.getElementById(blockid);
        if (block != null && block.intiallyopen != null && !block.intiallyopen) {
            block.style.display = "none";
            block = document.getElementById("CommentSection-" + this.bookmarkid);
            if (block != null) {
                block.style.display = "none";
            }
        }
        var inputs = this.getElementsByTagName("textarea");
        for (var i = 0; i < inputs.length; i++) {
            if (inputs[i].className == "b24-comment-textinput" || inputs[i].className == "b24-comment-textinput-active") {
                inputs[i].className = "b24-comment-textinput";
                inputs[i].beenfocused = false;
                inputs[i].value = YourCommentGoesHere;
                break;
            }
        }
        var links = this.getElementsByTagName("a");
        for (var i = 0; i < links.length; i++) {
            if (links[i].className == "n-profile") {
                links[i].style.display = "none";
                break;
            }
        }

    }
    comment.getCommentText = function() {   // gets the user input text
        var inputs = this.getElementsByTagName("textarea");
        for (var i = 0; i < inputs.length; i++) {
            if (inputs[i].className == "b24-comment-textinput" || inputs[i].className == "b24-comment-textinput-active") {
                text = inputs[i].value;
                return (text);
            }
        }
        return null;
    }

    comment.createComment = function() {     // how to create a comment
        NewCommentWorker(this);
    }
}

function CancelComment(commentid) {
    var comment = document.getElementById(commentid);
    var inputs = comment.getElementsByTagName("textarea");
    for (var i = 0; i < inputs.length; i++) {
        if (inputs[i].className == "b24-comment-textinput" || inputs[i].className == "b24-comment-textinput-active") {
            inputs[i].value = YourCommentGoesHere;
            break;
        }
    }
}

function NewComment(commentid) {
    var comment = document.getElementById(commentid);
    if (comment == null) {
        return;
    }
    NewCommentWorker(comment);
}

function NewCommentWorker(comment) {
    var xmlhttp = initXMLHttp();
    var url = igeserviceroot;
    xmlhttp.open("POST", url, true);
    var params = "method=NewComment";
    params += "&locationid=" + comment.bookmarkid;
    var text = comment.getCommentText();
    var commentRightSide = comment.commentRightSide;
    var done = false;
    var me = comment;
    var myparent = comment.parentNode;
    var noteblock = comment.noteblock;

    if (noteblock) {
        params += "&locationuri=" + escape(noteblock.LocationUri);
    }

    if (text == null || text.length == 0 || text == YourCommentGoesHere) {
        comment.cancelComment();  // nothing to do
        return;
    }
    //params += "&comment=" + escape(text);
    params += "&comment=" + encodeURIComponent( text);
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=utf-8"); // for post
    xmlhttp.onreadystatechange = function() {   // what to do when it succeeds or fails, don't really know
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            done = true;
            var _commentblock = me.commentblock;
            var _noteblock = me.noteblock;
            var _bookmarkid = me.bookmarkid;
            var _myparent = myparent;
            if (myparent == null) {
                return;
            }
            // change comment count
            ChangeCounts(_bookmarkid, comment.bookid, comment.chunkid, null, comment.elementid, true, false);
            var temp = document.createElement("div");
            temp.innerHTML = xmlhttp.responseText;  // this has a structure like: <div "<div> - added notes </div><div> - new empty create note form </div>"
            if (temp.firstChild) {   // will take the 2 top levels and insert them into the comment block
                var div = temp.firstChild.firstChild;
                while (div != null) {
                    var next = div.nextSibling;
                    if (div.nodeType == 1) {
                        div.parentNode.removeChild(div);   // remove it from here
                        myparent.appendChild(div);
                        IGEInitializeNotesAndComments(div, false);  // makes sure my data structures are OK
                    }
                    div = next;
                }
            }
            temp = null;
            myparent.removeChild(me);  // we've been replaced
        }
        else if (xmlhttp.readyState == 4 && xmlhttp.status == 400) {
            handleFailure(xmlhttp);
        }
        else if (xmlhttp.readyState == 4) {
            handleFailure(xmlhttp);
        }
        return;
    }
    if (igehasnotjoined) { // join them up and let them know the joy that awaits them - variable is set by the base master (and community.aspx)
        var clickedOn = me;
        if (me.clickedElement != null) {
            clickedOn = me.clickedElement;
        }
        JoinPrompt(clickedOn, xmlhttp, params, true, JoinPromptCommentThankyou, "OK");
        return;
    }
    else {
        xmlhttp.send(params);
    }
    return;
}

function ArtifactActivateComment(commentblock, noteblock, bookmarkid) {
    if (bookmarkid == null) {
        return;  // no prayer
    }
    var comment = document.getElementById("new-comment-" + bookmarkid);
    if (comment == null) {
        return;   // we're dead
    }
    ArtifactInitializeEmptyComment(noteblock, bookmarkid);
    comment.style.display = "inline";
}

function setbg(id,color) {
    document.getElementById(id).style.background = color
}
// 
// when they start typing in our comment, we make the 
function IGECommentFocus(commentid, color) {
    setbg(commentid, color);
    var textarea = document.getElementById(commentid);
    var parent = textarea.parentNode;
    if (NoteBlockRefreshRate > 0) {
        while (parent.nodeName.toLowerCase() == 'div') {
            parent = parent.parentNode;
        }
    }
    textarea.className = "b24-comment-textinput-active";
    var div = textarea.parentNode.parentNode;
    div = div.previousSibling;
    while (div != null) {
        if (div.className == "n-leftside") {
            var links = div.getElementsByTagName("a");
            if (links.length > 0) {
                links[0].style.display = "inline";
            }
            break;
        }
        div = div.previousSibling;
    }
}

//
// manage the twistie open
// id is what opens us.
// For Example: commentsection, note id, CommentSectionOpen, createComment
//
function TwistieOpen(prefix, id, fetchcommand, initializefunction, onfetchsuccess, sortorder) {
    var twistieblock = document.getElementById(prefix + "-control-" + id);
    if (twistieblock) {  // make sure the twistie itself is visible --- it isnt by default if there are no comments
        if (twistieblock.style.display == "none") {
            twistieblock.intiallyopen = false;
        }
        else {
            twistieblock.intiallyopen = true;
        }
        twistieblock.style.display = "block";
    }
    var imgopen = document.getElementById(prefix + "-" + id + "-open");  // the control images
    var imgworking = document.getElementById(prefix + "-" + id + "-working");
    var imgclosed = document.getElementById(prefix + "-" + id + "-closed");
    var imgrefresh = document.getElementById(prefix + "-" + id + "-refresh");
    if (imgopen == null || imgclosed == null || imgworking == null) {
        return;
    }
    var noteblock = null;
    
    var parent = document.getElementById("comment-" + id);
    if (parent == null) {
        while (parent != null && (parent.className == "b24-note" ||
                              parent.className == "b24-comment")) {
            parent = parent.parentNode;
        }
    }
    if (parent != null) {
        noteblock = parent;
        initializefunction(noteblock);
        parent.sortorder = sortorder;
    }

    
    var block = document.getElementById(prefix + '-' + id);
    if (block != null) {
        imgopen.style.display = "inline";   // fix the toggle and we're done
        imgworking.style.display = "none";
        imgclosed.style.display = "none";
        if (imgrefresh != null) {
            imgrefresh.style.display = "inline";
        }
        block.style.display = "";
        if (!block.IsInitialized) {
            if (initializefunction != null) {
                initializefunction(block,null,id);  // build any structures that need building
            }
        }
        if (onfetchsuccess) {                // except that they want an input box at the bottom
            onfetchsuccess(block, noteblock, id);
        }
        if (block.RefreshBlock != null) {  // reset the refresh timer and then find all our nested timers (like open comments
            if (block.RefreshBlock.RefreshSet != null && block.RefreshBlock.RefreshInterval == null) {
                block.RefreshBlock.RefreshInterval = setInterval(block.RefreshBlock.RefreshFunction, NoteBlockRefreshRate * 1000);
                var divlist = block.RefreshBlock.getElementsByTagName("div");
                for (var i = 0; i < divlist.length; i++) {
                    var div = divlist[i];
                    if (div.RefreshSet != null && div.RefreshInterval == null) {
                         div.RefreshInterval = setInterval(div.RefreshFunction, NoteBlockRefreshRate * 1000);
                    }
                }
            }
        }
        return;
    }
    // have to make ourself a comment section.
    var target = document.getElementById(prefix + '-' + id + "-target");
    if (target == null) {  // there's no place to put it.
        return;
    }
    target.NoteCommentContainer = true;
    target.setAttribute("id", prefix + '-' + id);
    target.className = "b24-" + prefix;
    imgopen.style.display = "none";  // signal that we're working on it
    imgworking.style.display = "inline";
    imgclosed.style.display = "none";
    if (imgrefresh != null) {
        imgrefresh.style.display = "inline";
    }
    var toggleSuccess = function() {
        imgopen.style.display = "inline";   // fix the toggle and we're done
        imgworking.style.display = "none";
        imgclosed.style.display = "none";
        if (imgrefresh != null) {
            imgrefresh.style.display = "inline";
        }
    }
    var toggleFailure = function() {
        imgopen.style.display = "none";   // fix the toggle and we're done
        imgworking.style.display = "none";
        imgclosed.style.display = "inline";
        if (imgrefresh != null) {
            imgrefresh.style.display = "none";
        }
    }
    fetchcommand(id, target, noteblock, onfetchsuccess, toggleSuccess, toggleFailure);    
}


/// the twistie close
function TwistieClose(id) {
    var imgopen = document.getElementById(id + "-open");
    var imgworking = document.getElementById(id + "-working");
    var imgclosed = document.getElementById(id + "-closed");
    var imgrefresh = document.getElementById(id + "-refresh");
    if (imgopen == null || imgclosed == null || imgworking == null) {
        return;
    }
    imgopen.style.display = "none";
    imgworking.style.display = "none";
    imgclosed.style.display = "inline";
    if (imgrefresh != null) {
        imgrefresh.style.display = "none";
    }
    var commentblock = document.getElementById(id);
    if (commentblock != null) { // for now
        commentblock.style.display = "none";
        if (commentblock.RefreshBlock != null) {  // clear our refresh timer and any of our children
            if (commentblock.RefreshBlock.RefreshSet != null && commentblock.RefreshBlock.RefreshInterval != null) {
                clearInterval(commentblock.RefreshBlock.RefreshInterval);
                commentblock.RefreshBlock.RefreshInterval = null;
                var divlist = commentblock.RefreshBlock.getElementsByTagName("div");
                for (var i = 0; i < divlist.length; i++) {
                    var div = divlist[i];
                    if (div.RefreshSet != null && div.RefreshInterval != null) {
                        clearInterval(div.RefreshInterval);
                        div.RefreshInterval = null;
                    }
                }
            }
        }
    }
}
//
// open everything
//
function TwistieOpenAll(event, targeturi, initializer, displayall) {
    if (event == null) {
        event = window.event;
    }
    var e = event;
    var targ = null;
    if (e != null) {
        if (e.target) {
            targ = e.target;
        }
        else if (e.srcElement) {
            targ = e.srcElement;
        }
        targ.saveClassname = targ.className;
        targ.className = targ.className + "-working";
    }
    if (targ == null) {
        return;
    }
    var original = targ;
    targ.cursorstyle = targ.style.cursor;
    targ.style.cursor = "wait";

    var parent = targ.parentNode;
    while (parent && !(parent.className == 'b24-userartifacts'|| parent.className == 'b24-commentsection')) {
        parent = parent.parentNode;
    }
    if (parent != null)
    {
        targ = parent;
        targ.cursorstyle = targ.style.cursor;
        targ.style.cursor = "wait";
    }
    var url = igeserviceroot;
    param = "method=GetArtifactsAtLocation&locationuri=" + escape(targeturi);
    param += TwistieAddOnNoteControls(targ, displayall);
    var anchor = document.getElementById("VideoAnnotationAnchor");
    if (anchor != null) {
        param += "&scrollbar=yes";
    }

    url = url + "?" + param;
    var xmlhttp = initXMLHttp();
    xmlhttp.open("GET", url, true);

    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 &&
            xmlhttp.status == 200) {
            original.style.cursor = original.cursorstyle;
            targ.style.cursor = targ.cursorstyle;
            targ.innerHTML = xmlhttp.responseText;
            initializer(targ);
        }
        else if (xmlhttp.readyState == 4) {
            original.style.cursor = original.cursorstyle;
            targ.style.cursor = targ.cursorstyle;
            targ.innerHTML = handleFailure(xmlhttp);
        }
    }

    xmlhttp.send(null);
}

function TwistieAddOnNoteControls(notesection,displayall) {
    var sortorderControlList = notesection.getElementsByTagName("select");
    var params = "&sortorder=";
    if (sortorderControlList != null && sortorderControlList.length > 0) {
        var selObj = sortorderControlList[0];
        var selIndex = selObj.selectedIndex;
        params += selObj.options[selIndex].value;
    }
    if (displayall != null && displayall == true) {
        params += "&showall=yes";
    }
    var checkboxList = notesection.getElementsByTagName("input");
    for (var i = 0; i < checkboxList.length; i++) {
        if (checkboxList[i].getAttribute("id") == "twistieshowall" && displayall == null) {
            if (checkboxList[i].getAttribute("type") == 'checkbox') {
                if (checkboxList[i].checked) {
                    params += "&showall=yes";
                }
            }
            else if (checkboxList[i].getAttribute("type") == 'hidden') {
            if (checkboxList[i].value == 'all') {
                params += "&showall=yes";
                }
            }
        }
        else if (checkboxList[i].getAttribute("id") == "twistieshowfollowers" && checkboxList[i].checked) {
            params += "&followersonly=yes";
        }
    }
    return params;
}
/**
 *  gets the comments for a note.  Will go back to the home planet if need be.
 */
function CommentSectionOpen(bookmarkid, target, noteblock, activateComment, toggleSuccess, toggleFailure) {
    if (!noteblock) {  // find our block container.  it has important information for us
        var parent = target.parentNode;
        while (parent != null && (parent.LocationUri == null)) {
            parent = parent.parentNode;
        }
        if (parent != null) {
            noteblock = parent;
        }
    }
    var targetParent = target.parentNode;
    var xmlhttp = initXMLHttp();
    var url = igeserviceroot;
    xmlhttp.open("POST", url, true);
    var params = "method=GetArtifactsAtLocation&HowMany=5";
    params += "&locationid=" + bookmarkid;
    if (noteblock) {
        params += "&locationuri=" + escape(noteblock.LocationUri);
    }
    var limits = document.getElementById("searchcommentids");
    if (limits != null) {
        params += "&searchcommentids=";
        if (limits.innerText) {
            params += limits.innerText;
        }
        else {
            params += limits.textContent;
        }
    }
    limits = document.getElementById("igefilterids");
    if (limits != null) {
        params += "&limitto=";
        if (limits.innerText) {
            params += limits.innerText;
        }
        else {
            params += limits.textContent;
        }
    }

    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=utf-8"); // for post
    xmlhttp.onreadystatechange = function() {   // what to do when it succeeds or fails, don't really know
        if (xmlhttp.readyState == 4 &&
                xmlhttp.status == 200) {
            toggleSuccess();
            var temp = document.createElement("div");
            temp.innerHTML = xmlhttp.responseText;
            if (temp.firstChild) {
                commentblock = temp.firstChild;
                temp.removeChild(commentblock);
                target.appendChild(commentblock);
                IGEInitializeNotesAndComments(commentblock);
                if (activateComment != null) {   // we're openning and adding a comment both.
                    activateComment(commentblock, noteblock, bookmarkid);
                }
            }
        }
        else if (xmlhttp.readyState == 4) {
            toggleFailure();
            target.innerHTML = handleFailure(xmlhttp);
        }
        return;
    }
    xmlhttp.send(params);
}
function handleFailure(xmlhttp) {
    if (xmlhttp.responseText == null) {
        return "<p style='color:red'>Response: unknown error</p>";
    }
    if (xmlhttp.responseText.indexOf("code='1'") != -1) {   // they've lost their authentication,  this will get them a login.
        window.location.reload();
    }
    else if (xmlhttp.responseText.indexOf("code=\"1\"") != -1) {
        window.location.reload();
    }
    else if (xmlhttp.responseText.indexOf("code=1") != -1) {
        window.location.reload();
    }
    else {
        return "<p style='color:red'>Response:" + xmlhttp.status + " " + xmlhttp.responseText + "</p>";
    }
}

//
// get the notes for a para in the viewer.
//
function FetchViewerNotes(bookmarkid, target, noteblock, activateComment, toggleSuccess, toggleFailure) {
    var parent = target;
    var info;
    while (parent != null) {
        if (parent.nodeType != 1) {
            parent = null;
            break;
        }
        info = parent.getAttribute("info");
        if (info != null && info.length > 0) {
            break;
        }
        parent = parent.parentNode;
    }
    if (parent == null) {
        toggleFailure();
        return;
    }
    var locatoruri = info;
    FetchNotes(bookmarkid, target, locatoruri, "isbookmark",toggleSuccess, toggleFailure);
}
//
// get the notes for the toc.  there can be book wide ones or those for the set of chunks make up a chapter
//
function FetchTocNotes(bookmarkid, target, noteblock, activateComment, toggleSuccess, toggleFailure) {
    var parent = target.parentNode;
    var bookid;
    while (parent != null) {
        if (parent.nodeType != 1) {
            parent = null;
            break;
        }
        bookid = parent.getAttribute("bookid");
        if (bookid != null && bookid.length > 0) {
            break;
        }
        parent = parent.parentNode;
    }
    if (parent == null) {
        toggleFailure();
        return;
    }
    exclude = "isbookmark";
    var sectionlist = parent.getAttribute("sectionlist");
    var locatoruri = "";
    if (sectionlist == null || sectionlist == "") {
        locatoruri = "?bookid=" + bookid;
        exclude += ",chunkid";
    }
    else {        
        var sections = sectionlist.split(',');
        for (var i = 0; i < sections.length; i++) {
            if (locatoruri.length > 0) {
                locatoruri += ",";
            }
            locatoruri += "?bookid=" + bookid + "&chunkid=" + sections[i];
        }
    }
    FetchNotes(bookmarkid, target, locatoruri, exclude, toggleSuccess, toggleFailure);
}
//
// does the ajax to get the notes 
//
function FetchNotes(bookmarkid, target, locatoruri, exclude, toggleSuccess, toggleFailure) {
    var xmlhttp = initXMLHttp();
    var url = igeserviceroot;
    xmlhttp.open("POST", url, true);
    var params = "method=GetArtifactsAtLocation";
    params += "&locationuri=" + escape(locatoruri);
    if (exclude != null && exclude.length > 0) {
        params += "&exclude=" + exclude;
    }
    var anchor = document.getElementById("VideoAnnotationAnchor");
    if (anchor != null) {
        params += "&scrollbar=yes";
    }
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=utf-8"); // for post
    xmlhttp.onreadystatechange = function() {   // what to do when it succeeds or fails, don't really know
        if (xmlhttp.readyState == 4 &&
                xmlhttp.status == 200) {
            toggleSuccess();
            var temp = document.createElement("div");
            temp.innerHTML = xmlhttp.responseText;
            if (temp.firstChild) {
                commentblock = temp.firstChild;
                temp.removeChild(commentblock);
                target.appendChild(commentblock);
                IGEInitializeNotesAndComments(commentblock);
            }
        }
        else if (xmlhttp.readyState == 4) {
            toggleFailure();
            var temp = document.createElement("div");
            temp.innerHTML = handleFailure(xmlhttp);
            target.appendChild(temp);
        }
        return;
    }
    xmlhttp.send(params);
}

///
function IGEInitializeNote(note) {
    note.IsInitialized = true;
    var IGEUri = note.getAttribute("info");
    if (IGEUri == null) {
        note.IGEEdit = function() {
        }
        note.IGERefresh = function() {
        }
        note.IGEDelete = function() {
        }
        note.IGETag = function() {
        }
        note.IGEYes = function() {
        }
        note.IGENo = function() {
        }
        note.IGEComment = function() {
        }
        note.IGEPleaseJoin = function() {
        }
        note.IGEShare = function() {
        }
        note.IGEReportAbuse = function() {
        }
        note.IGERemoveAbuseFlag = function() {
        }
        return null;
    }
    SetParams(note,IGEUri);
    note.IGEEdit = function() {
        var e = this.event;
        if (e == null) {
            e = window.event;
        }
        var targ = null;
        if (e != null) {
            if (e.target) {
                targ = e.target;
            }
            else if (e.srcElement) {
                targ = e.srcElement;
            }
            targ.saveClassname = targ.className;
            targ.className = targ.className + "-working";
        }
        ShowAnnotationDialog(this.bookid, this.chunkid, this.ContainerId, 0 /*iscorporatenote*/);
        if (targ != null) {
            targ.className = targ.saveClassname;
        }
    }
    note.IGEDelete = function() {
        var e = this.event;
        if (e == null) {
            e = window.event;
        }
        var targ = null;
        if (e != null) {
            if (e.target) {
                targ = e.target;
            }
            else if (e.srcElement) {
                targ = e.srcElement;
            }
        }
        this.ConfirmText = DeletingANote;
        this.ConfirmQuestion = DoYouWishToDeleteThis;
        this.ConfirmFunction = "ActuallyDelete";
        Confirmation(targ, this);
    }
    note.IGERefresh = function() {  // get any new/changed comments
        var e = this.event;
        if (e == null) {
            e = window.event;
        }
        var targ = null;
        if (e != null) {
            if (e.target) {
                targ = e.target;
            }
            else if (e.srcElement) {
                targ = e.srcElement;
            }
        }
        var ourelement = this;
        NoteRefresh(ourelement);
    }
    note.IGEReportAbuse = function() {
        var e = this.event;
        if (e == null) {
            e = window.event;
        }
        var targ = null;
        if (e != null) {
            if (e.target) {
                targ = e.target;
            }
            else if (e.srcElement) {
                targ = e.srcElement;
            }
        }
        this.ConfirmText = FlaggingNotesAndComments;
        this.ConfirmQuestion = DoYouWishToFlagAsInappropriate;
        this.ConfirmFunction = "ReportAbuse";
        Confirmation(targ, this);
    }
    note.IGETag = function() {
    }
    note.IGEYes = function() {
    }
    note.IGENo = function() {
    }
    note.IGEComment = function() {  // add a comment,  this makes sure the twistie is open and fetched and then calls the new comment code
        var e = this.event;
        if (e == null) {
            e = window.event;
        }
        var targ = null;
        if (e != null) {
            if (e.target) {
                targ = e.target;
            }
            else if (e.srcElement) {
                targ = e.srcElement;
            }
            targ.saveClassname = targ.className;
            targ.className = targ.className + "-working";
        }

        TwistieOpen("CommentSection", this.ContainerId, CommentSectionOpen, ArtifactActivateComment);  // make sure the section is open, opens it and if necessary makes a new comment block
        if (targ != null) {
            targ.className = targ.saveClassname;
        }
    }
    note.IGEPleaseJoin = function() {  // add a comment,  this makes sure the twistie is open and fetched and then calls the new comment code
        var e = this.event;
        if (e == null) {
            e = window.event;
        }

        var targ = null;
        if (e != null) {
            if (e.target) {
                targ = e.target;
            }
            else if (e.srcElement) {
                targ = e.srcElement;
            }
            targ.saveClassname = targ.className;
            targ.className = targ.className + "-working";
        }
        this.ConfirmQuestion = null;
        this.ConfirmText = InOrderToAddYourCommentBefore;
        this.ConfirmText += "<a href='myprofile.aspx?mode=1' target='_parent'>";
        this.ConfirmText += InOrderToAddYourCommentLink;
        this.ConfirmText += "</a>";
        this.ConfirmText += InOrderToAddYourCommentAfter;        
        Confirmation(targ, this);
    }
    note.IGEShare = function() {
    }
    note.IGERemoveAbuseFlag = function() {
        var xmlhttp = initXMLHttp();
        var url = igeserviceroot;
        xmlhttp.open("POST", url, true);
        var params = "method=RemoveAbuseFlag";
        var comment = this;
        params += "&locationid=" + this.ContainerId;
        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=utf-8"); // for post
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                var parent = comment.parentNode;
                var temp = document.createElement("div");
                temp.innerHTML = xmlhttp.responseText;  // this has a structure like: <div "<div> - added notes </div><div> - new empty create note form </div>"
                if (temp.firstChild) {   // will take the 2 top levels and insert them into the comment block
                    var newOne = temp.firstChild;
                    temp.removeChild(newOne);
                    parent.replaceChild(newOne, comment);
                    IGEInitializeNotesAndComments(comment);  // for now.  will want to set some differently later maybe
                }
            }
            else if (xmlhttp.readyState == 4) {
                handleFailure(xmlhttp);
            }
        }
        xmlhttp.send(params);
    }
/*     note.RefreshSet = true;
    note.RefreshFunction = function() { NoteRefresh(note); };
    note.RefreshInterval = null;
    */
    return note;
}

//
// initialize the comment.  same as a note except for the edit (at least for now)
//
function IGEInitializeComment(comment) {
    comment.IsInitialized = true;
    comment.isBlankForm = false;
    IGEInitializeNote(comment);  // for now.  will want to set some differently later maybe
    var id = "" + comment.getAttribute("id");
    if (id.indexOf("new-comment") == 0) {
        ArtifactInitializeCommentForm(comment, null);
    }
    if (!comment.isBlankForm) {
        comment.cancelComment = function() {     // give it a cancel function
            var inputs = this.getElementsByTagName("textarea");
            var i = 0;
            for (i = 0; i < inputs.length; i++) {
                if (inputs[i].className == "b24-comment-textinput" || inputs[i].className == "b24-comment-textinput-active") {
                    inputs[i].value = YourCommentGoesHere;
                    break;
                }
            }
            var divs = this.getElementsByTagName("div");
            for (i = 0; i < divs.length; i++) {
                if (divs[i].className == "b24-comment-form") {
                    divs[i].style.display = "none";
                }
                else if (divs[i].className == "n-rightside") {
                    
                }
                else if (divs[i].className == "n-seperator") {
                    break;
                }
                else {
                    divs[i].style.display = "inline";
                }
            }
        }
        comment.getCommentText = function() {   // gets the user input text
            var inputs = this.getElementsByTagName("textarea");
            for (var i = 0; i < inputs.length; i++) {
                if (inputs[i].className == "b24-comment-textinput" || inputs[i].className == "b24-comment-textinput-active") {
                    text = inputs[i].value;
                    return (text);
                }
            }
            return null;
        }

        comment.createComment = function() {     // how to create a comment

            var xmlhttp = initXMLHttp();
            var url = igeserviceroot;
            xmlhttp.open("POST", url, true);
            var params = "method=UpdateComment";
            var id = "" + this.getAttribute("id");
            var where = id.indexOf('-');
            if (where != -1) {
                id = id.substring(where + 1);
            }
            params += "&id=" + id;
            var text = this.getCommentText();
            //params += "&text=" + escape(text);
            params += "&text=" + encodeURIComponent(text);
            if (text == null || text.length == 0 || text == YourCommentGoesHere) {
                this.cancelComment();  // nothing to do
                return;
            }
            xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=utf-8"); // for post
            xmlhttp.onreadystatechange = function() {   // what to do when it succeeds or fails, don't really know
                return;
            }
            xmlhttp.send(params);
            var divs = this.getElementsByTagName("div");
            for (var i = 0; i < divs.length; i++) {
                if (divs[i].className == "b24-comment-form") {
                    divs[i].style.display = "none";
                }
                else if (divs[i].className == "n-seperator") {
                    break;
                }
                else if (divs[i].className == "n-text") {
                    divs[i].innerHTML = text;
                    divs[i].style.display = "";
                }
                else {
                    divs[i].style.display = "";
                }
            }
            return;
        }

        comment.IGEEdit = function() {
            var e = this.event;
            if (e == null) {
                e = window.event;
            }
            var targ = null;
            if (e != null) {
                if (e.target) {
                    targ = e.target;
                }
                else if (e.srcElement) {
                    targ = e.srcElement;
                }
            }
            var leftright = comment.firstChild;
            while (leftright) {   // look for the rightside of our comment --- it has the displayed text and a hidden form
                if (leftright.className == "n-rightside") {
                    var text = "";
                    var child = leftright.firstChild;
                    while (child != null) {
                        if (child.className == "b24-comment-form") {  // here's the hidden form.  it came after the text.  initialize the text inpug
                            var fchild = child.firstChild;
                            while (fchild != null) {   // find the text input
                                if (fchild.className == "b24-comment-textinput") {
                                    fchild.value = text;   // it's initial value
                                }
                                fchild = fchild.nextSibling;
                            }
                            child.style.display = "inline";   // make the form visible
                        }
                        else if (child.className == "n-seperator") {
                            break;
                        }
                        else {   // everything else becomes invisible
                            if (child.style != null) {
                                child.style.display = "none";
                                if (child.className == "n-text") {   // pick up the current text
                                    if (child.innerText) {
                                        text = child.innerText;
                                    }
                                    else {
                                        text = child.textContent;
                                    }
                                }
                            }
                        }
                        child = child.nextSibling;
                    }
                    break;
                }
                leftright = leftright.nextSibling;
            }
        }
    }
}

function IGEInitializeNotesAndComments(container, skiprefresh) {
    if (container.IsInitialized) {
        return;
    }
    var targetid = null;
    var time = 0;
    if (container.className == "b24-comment") {
        IGEInitializeComment(container);
        return;
    }
    else if (container.className == "b24-note") {
        IGEInitializeNote(container);
        return;
    }
    if (container.nodeType != 1) {
        return;
    }
    var divlist = container.getElementsByTagName("div");
    container.IsInitialized = true;
    for (var i = 0; i < divlist.length; i++) {
        var div = divlist[i];
        if (targetid == null) {
            var locator = div.getAttribute("info");
            if (locator != null && locator != "") {
                targetid = locator;
                container.setAttribute("info", locator);
            }
        }
        if (div.className == "b24-comment") {
            IGEInitializeComment(div);
            sawComment = true;
            var ctime = div.getAttribute("threadmodifiedtime");
            if (ctime != null) {
                ctime = parseInt(ctime);
                if (ctime > time) {
                    time = ctime;
                }
            }
        }
        else if (div.className == "b24-note") {
            IGEInitializeNote(div);
            var ctime = div.getAttribute("threadmodifiedtime");
            if (ctime != null) {
                ctime = parseInt(ctime);
                if (ctime > time) {
                    time = ctime;
                }
            }
        }
    }

    container.IGERefresh = function() {  // get any new/changed comments
        var ourelement = this;
        ourelement.RefreshStop = false;
        NoteRefresh(ourelement);
    }

    container.setAttribute("threadmodifiedtime", time);
    container.RefreshSet = true;
    container.RefreshFunction = function() { NoteRefresh(container); };
    container.RefreshInterval = null;
    var parent = container.parentNode;
    while (parent != null && parent.nodeName.toLowerCase() == "div") {   // provide a link here
        if (parent.NoteCommentContainer != null) {
            parent.RefreshBlock = container;
            break;
        }
        parent = parent.parentNode;
    }
    if (NoteBlockRefreshRate > 0) {
        if (container != null && container.RefreshBlock != null) { // its already been set up
        }
        else if (container != null && container.RefreshSet != null && container.RefreshInterval == null) {
          container.RefreshInterval = setInterval(container.RefreshFunction, NoteBlockRefreshRate * 1000);
        }
    }
}

function SetupVideoRefreshTimer(id) {
    var element = document.getElementById(id);
    if (element == null) {
        return;
    }
    var parent = element.parentNode;
    parent.RefreshBlock = element;
    NoteBlockRefreshRate = 60;
    element.RefreshFunction = function() { NoteRefresh(element); };
    element.RefreshSet = true;
    element.RefreshInterval = setInterval(element.RefreshFunction, NoteBlockRefreshRate * 1000);
}


///
///  little function that weasles into our object
///
function IGEFunction(event, method, id) {
    var container = document.getElementById(id);
    var e = this.event;
    if (e == null) {
        e = window.event;
    }

    var targ = null;
    if (e != null) {
        if (e.target) {
            targ = e.target;
        }
        else if (e.srcElement) {
            targ = e.srcElement;
        }
    }
    if (container != null) {
        container.clickedElement = targ;
        IGEInitializeNotesAndComments(container);
        container.event = event;
        IGECheckCreateButtonClick(container, method);
        var dynamic = "container." + method + "()";
        eval(dynamic);
    }
}
function IGECheckCreateButtonClick(container, method) {
    var img = container.getElementsByTagName("img");
    if (img != null) {
        if (method == "createComment") {
            var text = container.getCommentText();
            if (text == YourCommentGoesHere) return;

            img[1].disabled = true;   // this should be the image for create, disable it to avoid double clicking
            img[1].onclick = null;
        }
    }
}
//
// splits the locator uri into its constituent parts
//
function SetParams(container,IGEUri) {
    container.LocationUri = IGEUri;
    if (IGEUri.indexOf('?') == 0) {
        IGEUri = IGEUri.substring(1);
    }
    var where = 0;
    var params = IGEUri.split("&");
    for (var i = 0; i < params.length; i++)
    {
        where = params[i].indexOf('=');
        if (where > -1)
        {
            var left = params[i].substring(0,where);
            var right = params[i].substring(where + 1);
            container[left] = right;
        }
    }
    var id = container.getAttribute("id");
    where = id.indexOf('-');
    if (where != -1) 
    {
        id = id.substring(where + 1);
    }
    container.ContainerId = id;
}
///
/// writes out our own twistie
///
function NewTwistie(prefix, id, initializeFunction) {
    if (initializeFunction == null) {
        initializeFunction = "IGEInitializeNotesAndComments";
    }
    var html = "<div class='b24-twistie' id='" + prefix + "-control-" + id + "'>";
    html += "<a class='n-control-link' id='" + prefix + "-" + id + "-closed' onclick='TwistieOpen(\"" + prefix + "\",\"" + id + "\",FetchTocNotes,IGEInitializeNotesAndComments,null)' style=';display:none;'>";
    html += "<img class='b24-expando' height='13' width='13' border='0' title='Notes (how about the importance of giving back talk?)' alt='Notes (how about the importance of giving back talk?)' style='display:inline; vertical-align:text-top; cursor: pointer' src='images/dui_arrowup.gif'/>";
    html += "</a>";
    html += "<a id='" + prefix + "-" + id + "-working' style='display:none; vertical-align:text-top; cursor: pointer'>";
    html += "<img class='b24-expando' height='13' width='13' border='0' title='loadingNotes' alt='loadingNotes' style='display:inline; vertical-align:text-top; cursor: pointer' src='images/b24-hourglass.gif'/>";
    html += "</a>";
    html += "<a id='" + prefix + "-" + id + "-open' onclick='TwistieClose(\"" + prefix + "-" + id + "\")' style='vertical-align:text-top; cursor: pointer;display:inline;'>";
    html += "<img class='b24-expando' height='13' width='13' border='0' title='Notes' alt='Notes' style='display:inline; vertical-align:text-top; cursor: pointer' src='images/dui_arrowdown.gif'/>";
    html += "</a>";
    html += "<span class='twistie-label'> Notes</span>";
    html += "<img width='12' height='12' border='0' style='vertical-align:text-bottom' src='images/i_sm_annotation.gif' hspace='1' alt='Notes (2) ' title='Notes (2)' id='128'/>";
    html += "<a class='n-refresh-link' id='" + prefix + "-" + id + "-refresh' style='vertical-align:text-top; cursor: pointer; float: right;;display:inline;' onclick='RefreshBlock(event,\"" + prefix + "-" + id + "\")'>";
    html += "<img width='16' height='16' border='0' style='cursor: pointer;' alt='Refresh with any new activity' title='Refresh with any new activity' src='images/refresh_icon.gif'/>";
    html += "</a>";
    html += "</div>";
    html += "<div id='" + prefix + "-" + id + "' class='b24-NotesSection'>";
    html += "<div id='" + prefix + "-" + id + "-newcontent' class='b24-userartifacts'>";
    html += "</div>";
    html += "</div>";
    
    return html;
}

///
/// delete/abuse confirmation bubble
///
//=====================================
//this.ConfirmText = "Flagging notes and comments as inappropriate removes the text from view.  They will be reviewed by your system administrator for final disposition.";
//this.ConfirmQuestion = "Do you wish to flag this as inappropriate?";
//this.ConfirmFunction = ReportAbuse;
//====================
function Confirmation(element, comment) {
    var thisdoc = document;
    var bubble = document.getElementById('download');
    if (bubble == null) {
        bubble = document.createElement("div");
        bubble.className = "b24-download-bubble";
        bubble.setAttribute("id", "download");
        document.body.appendChild(bubble);
    }

    AnnotationRemoveContentDecorations(bubble, thisdoc);

    if (bubble.style.display == "inline") {
        SunDown();
    }
    bubble.innerHTML = "";
    bubble.className = "b24-citation_bubble";
    var elepos = getPosition(element);
    var viewportdem = getViewportSize(document);
    var scrollpos = null;
    var contentdiv = document.getElementById('container');
    var contentDivVert = 0;
    if (contentdiv != null) {
      var contentdivpos = getPosition(contentdiv);
      elepos[0] -= contentdivpos[0];
      elepos[1] -= contentdivpos[1];
      contentDivVert = contentdivpos[1];
      scrollpos = getScrollingPositionElm(thisdoc, contentdiv);
    }
    else {
      scrollpos = getScrollingPosition(thisdoc);
    }
    var relobjpos = elepos[1] - scrollpos[1];
    var halfviewport = Math.round(viewportdem[1] / 2);
    var tailgoes = ((relobjpos < halfviewport) || (location.href.indexOf("toc.aspx") >= 0) || (location.href.indexOf("viewer_r.asp") >= 0)) ? "up" : (relobjpos > halfviewport) ? "down" : null;
    // yes, it is hardcoded, but it is only for cases when bubble slips below the edge of the screen.
    // we don't know what the height will be before the bubble is already created.
    var bubbleheight = 120;
    if (bubble.offsetHeight > 0)
        bubbleheight = bubble.offsetHeight; //bubble.clientHeight;
    var poptop;
    if (tailgoes == "up") {
        poptop = elepos[1];
    }
    else {
        poptop = elepos[1] - bubbleheight;
    }
    if (bubbleheight + relobjpos > viewportdem[1]) {
        var adjustment = viewportdem[1] - bubbleheight - relobjpos;
        poptop = poptop + adjustment;
    }

    bubble.style.top = parseInt(poptop) + "px";
    bubble.style.width = 380;
    var bubbleleft = elepos[0] - (380 / 2);
    bubble.style.left = parseInt(bubbleleft) + "px";
    if (bubbleleft + 390 > viewportdem[0]) {
        bubble.style.left = parseInt(elepos[0] - 380) + "px";
    }
    bubble.style.display = "inline";
    var focuser = new Focuser("focusitem1");
    focuser.SetIntervalID(setInterval(focuser.SetFocus, 2000));
    var html = "<div class='dialog'>";
    html += "<div class='content'>";
    html += "<div class='t'></div>";
    html += "<div class='r'><A HREF='javascript:void(0)' onclick='javascript:SunDown();'><IMG SRC='images/bubble_x.gif' border='0' height='7' width='5' alt='" + ConfirmClose + "' title='" + ConfirmClose + "' onclick='javascript:SunDown();'></A></div>";
    html += "<p class='hd'>";
    if (comment.ConfirmQuestion != null) {
        html += PleaseConfirmThisAction;
    }
    html += "</p>";
    html += "<p><div class='b24-citations-content'>";
    html += "<p class='c-confirmmessage'>" + comment.ConfirmText + "</p>";
    if (comment.ConfirmQuestion != null) {
        html += "<p class='c-confirmquestion'>" + comment.ConfirmQuestion + " <a class='n-control-link' onclick='" + comment.ConfirmFunction + "(\"" + comment.getAttribute("id") + "\");SunDown();'>" + ConfirmYes + "</a> <a class='n-control-link' onclick='SunDown();'>" + ConfirmNo + "</a></p>";
    }
    html += "</div></p>";
    html += "</div>";
    html += "<div class='b'><div></div></div>";
    html += "</div>";
    bubble.innerHTML = html;
}

///
/// does the report as inappropriate --- called by the confirmation bubble
///
function ReportAbuse(commentid) {
    var comment = document.getElementById(commentid);
    var xmlhttp = initXMLHttp();
    var url = igeserviceroot;
    xmlhttp.open("POST", url, true);
    var params = "method=ReportAbuse";
    params += "&locationid=" + comment.ContainerId;
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=utf-8"); // for post
    xmlhttp.onreadystatechange = function() { }
    xmlhttp.send(params);
    var divs = comment.getElementsByTagName("div");
    for (var i = 0; i < divs.length; i++) {
        if (divs[i].className == "n-text") {   // pick up the current text
            divs[i].innerHTML = "<span class='n-inappropriate'>Content reported to be inappropriate</span>";
        }
        else if (divs[i].className == "n-label") {
            divs[i].innerHTML = "<span class='n-inappropriate'>Content reported to be inappropriate</span>";
        }
    }

  var imgs = comment.getElementsByTagName("img");
    for (var i = 0; i < imgs.length; i++) {
        if (imgs[i].title == "Report Abuse") {   // pick up the current text
            imgs[i].src = "images/i_inappropriate.jpg";
            imgs[i].alt = "Flagged as Inappropriate";
            imgs[i].title = "Flagged as Inappropriate";
            imgs[i].width = "11";
            imgs[i].height = "11";
            imgs[i].onclick = "";
        }
    }

    var parent = comment.parentNode;
    parent.RefreshBlock = comment;
}

///
///  does the delete ajax, called by the confirmation
///
function ActuallyDelete(commentid) {
    var comment = document.getElementById(commentid);
    var isNote = false;
    if (comment != null) {
        if (comment.className == "b24-note") {
            isNote = true;
            ChangeCounts(comment.ContainerId, comment.bookid, comment.chunkid, null, comment.elementid, false,true );
        }
        if (comment.className == "b24-comment") {
            var _bookmarkid = comment.noteid;
            ChangeCounts(_bookmarkid, comment.bookid, comment.chunkid, null, comment.elementid, false, false);
        }
    }
    var xmlhttp = initXMLHttp();
    var url = igeserviceroot;
    xmlhttp.open("POST", url, true);
    var params = "method=Delete";
    params += "&locationid=" + comment.ContainerId;
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=utf-8"); // for post
    xmlhttp.onreadystatechange = function() {
    }
    if (isNote) {
        var tocframe = top.frames["Toc"];
        if (tocframe != null) {
            xmlhttp.onreadystatechange = function() {
                if (xmlhttp.readyState == 4 &&
                    xmlhttp.status == 200) {
                    tocframe.location.reload();
                }
                else if (xmlhttp.readyState == 4) {
                    handleFailure(xmlhttp);
                }
            }
        }
    }
    xmlhttp.send(params);
    comment.style.display = "none";
}
//
// ajax controlled follow button, we either follow or stop following this guy
function FollowMe(event, profileid, yesno) {
    var thisdoc = top.document;
    var bubble = thisdoc.getElementById("controlbubble");
    var element = null;
    if (event == null) {
        event = window.event;
    }
    if (event.target) {
        element = event.target;
    }
    else if (event.srcElement) {
        element = event.srcElement;
    }
    element.style.display = "none";
    var followcontrol = element;
    if (yesno == 1) {
        var next = element.nextSibling;
        while (next != null) {
            if (next.nodeName == "img" || next.nodeName == "IMG") {
                next.style.display = "inline";
                followcontrol = next;
                break;
            }
            next = next.nextSibling;
        }
    }
    else {
        var next = element.previousSibling;
        while (next != null) {
            if (next.nodeName == "img" || next.nodeName == "IMG") {
                next.style.display = "inline";
                followcontrol = next;
                break;
            }
            next = next.previousSibling;
        }
    }
    var xmlhttp = initXMLHttp();
    var url = igeserviceroot;
    xmlhttp.open("POST", url, true);
    var params = "method=FollowMe&yesno=" + yesno + "&profileid=" + profileid;
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=utf-8"); // for post
    xmlhttp.onreadystatechange = function() {   // what to do when it succeeds or fails, don't really know
    }

    if (igehasnotjoined) {  // join them up
        JoinPrompt(followcontrol, xmlhttp, params, false, JoinPromptFollowThankyou, "Follow &amp; join the Community");
        return;
    }
    else {
        xmlhttp.send(params);
    }

}

var slideToAHalt = false;

var bubblecount = 0;
function ShowControl(event, controlurl, delay, frame, redisplay, zoom) {
    if (slideToAHalt) {  // try to fix IEs willingness to execute mouseovers when the sliding is taking place
        return;
    }
    if (redisplay == null) {
        redisplay = false;
    }
    //Fix for defect #195790
    var thisdoc = document;
    try {
        thisdoc = top.document;
    } catch (e) { }

    var contentframe = null;
    contentframe = SetContentFrame();
    if (contentframe != null) {
        thisdoc = contentframe.document;
    }

    var element = null;
    if (event == null) {
        event = window.event;
    }

    if (event.target) {
        element = event.target;
    }
    else if (event.srcElement) {
        element = event.srcElement;
    }
    var originalelement = null;
    if (delay == 0) {
        originalelement = element;
        originalelement.cursorstyle = element.style.cursor;
        element.style.cursor = "wait";
    }

    var bubble = null;
    if (redisplay) { // some control in the dialog was picked
        while (element != null && element.nodeType == 1 && element.className != 'b24-citation_bubble') {
            element = element.parentNode;
        }
        if (element && element.nodeType == 1) {
            bubble = element;
        }
    }
    else {
        bubble = element.bubble;
    }
    if (bubble == null) {
        bubble = thisdoc.createElement("div");
        bubble.setAttribute("id", "controlbubble");
        bubble.className = "b24-citation_bubble";
        bubble.style.display = "none";
        thisdoc.body.appendChild(bubble);
        bubble.redisplay = false;
        element.bubble = bubble;
        bubble.originalelement = originalelement;
        bubble.delay = delay;
    }
    else {
        bubble.delay = delay;
        bubble.originalelement = originalelement;
        bubble.redisplay = redisplay;
        if (bubble.style.display != "none") {
            bubble.tovar = null;
            if (controlurl != null && controlurl.length > 0) {
                if (redisplay) {
                    bubble.controlurl = controlurl;
                    bubble.element = element;
                    ShowControlAfterDelay(bubble);  // show immediately
                    return;
                }
                else {
                    if (bubble.controlurl == controlurl) {
                        if (delay != null && delay == 0) {  // turn it into a toggle
                            HideControl(event,1);
                        }
                        return;
                    }
                    else {
                        bubble.controlurl = controlurl;
                        bubble.element = element;
                        ShowControlAfterDelay(bubble);  // show immediately
                        return;
                    }
                }
            }
        }
    }
    if (bubble) {
        if (zoom != null && zoom != 0) {
            bubble.imgheight = element.height;
            bubble.imgwidth = element.width;
            element.height = element.height * zoom;
            element.width = element.width * zoom;
        }
        bubble.shielded = null;
        if (frame != null) {
            bubble.frame = frame;
        }
        else {
            bubble.frame = null;
        }
        bubble.element = element;
        bubble.controlurl = controlurl;
        if (controlurl != null && controlurl.length > 0) {
            if (delay != null && delay == 0) {
                ShowControlAfterDelay(bubble);
            }
            else {
                if (delay == null) {
                    delay = 500;
                }
                var delayedbubble = function() { ShowControlAfterDelay(bubble); };
                bubble.tovar = setTimeout(delayedbubble, delay);
            }
        }
    }
}
function ShieldControl() {
    var thisdoc = top.document;
    var thebubblediv = thisdoc.getElementById("controlbubble");
    thebubblediv.tovar = null;
    thebubblediv.shielded = true;
}

function CloseControl(event) {
    var element = null;
    if (event == null) {
        event = window.event;
    }

    if (event.target) {
        element = event.target;
    }
    else if (event.srcElement) {
        element = event.srcElement;
    }
    if (element == null) {
        return;
    }
    
    while (element != null && element.nodeType == 1 && element.className != 'b24-citation_bubble') {
        element = element.parentNode;
    }
    if (element && element.nodeType == 1) {
        var bubble = element;
        CloseControlInternal(bubble.element,bubble);
    }
}

function HideControl(event,forsure) {
    var element = null;
    if (event == null) {
        event = window.event;
    }

    if (event.target) {
        element = event.target;
    }
    else if (event.srcElement) {
        element = event.srcElement;
    }
    var thisdoc = top.document;
    var thebubblediv = null;
    if (element) {
        thebubblediv = element.bubble;
    }
    if (thebubblediv) {
        if (thebubblediv.tovar != null) {
            clearTimeout(thebubblediv.tovar);
        }
        thebubblediv.tovar = null;
        if (thebubblediv.originalelement != null) {
            thebubblediv.originalelement.style.cursor = "pointer";
        }
        if (thebubblediv.imgheight) {
            thebubblediv.element.height = thebubblediv.imgheight;
            thebubblediv.element.width = thebubblediv.imgwidth;
            thebubblediv.imgheight = null;
            thebubblediv.imgwidth = null;
        }
        if (true || forsure) {
            CloseControlInternal(element,thebubblediv);
        }
        else {
            if (thebubblediv.shielded != null && thebubblediv.shielded) {
                thebubblediv.shielded = null;
            }
            else {
                thebubblediv.tovar = setTimeout("HideControl(event,true)", 100);
            }
        }
    }
}

function CloseControlInternal(element, thebubblediv) {
    if (element == null && thebubblediv == null) {
        return;
    }
    if (thebubblediv == null) {
        thebubblediv = element.bubble;
    }
    else if (element == null) {
       element = thebubblediv.element;
   }
   if (element != null) {
       element.bubble = null;
   }
    if (thebubblediv == null) {
        return;
    }
    if (thebubblediv.parentNode != null) {
        thebubblediv.parentNode.removeChild(thebubblediv);
    }
    thebubblediv.style.display = "none";
    thebubblediv.tovar = null;
    thebubblediv.controlurl = null;
    thebubblediv.element = null;
    thebubblediv.count = 0;
    thebubblediv.shielded = null;
}
///
/// a profile in a bubble
///
function ShowControlAfterDelay(bubble) {
    if (bubble == null) {
        return;
    }
    //Fix for defect #195790
    var thisdoc = document;
    try {
        thisdoc = top.document;
    } catch (e) { }

    var contentframe = null;
    var contentwindow = top.window;
    contentframe = SetContentFrame();
    if (contentframe != null) {
        thisdoc = contentframe.document;
        contentwindow = contentframe.window;
    }

    bubble.tovar = null;
    if (bubble.element == null || bubble.controlurl == null) {
        return;
    }
    bubble.count = ++bubblecount;
    var count = bubble.count;   // oneup identifier
    var controlurl = bubble.controlurl;
    if (!bubble.redisplay) {
        //Fix for defect #195790
        var viewportdem = calcViewportSize(contentwindow, thisdoc);
        var elepos = getPosition(bubble.element);
        if (bubble.frame != "none") {
            var iframe = thisdoc.getElementById("ActivityStream");
            if (iframe != null) {
                var iframepos = getPosition(iframe);
                elepos[0] = iframepos[0] - 380;
                elepos[1] += iframepos[1];
            }
            else {
                iframe = thisdoc.getElementById("CommunityIFrame");
                if (iframe != null) {
                    iframepos = getPosition(iframe);
                    elepos[1] = iframepos[1] - 100 + elepos[1];
                    elepos[0] = iframepos[0] - 100;
                }
            }
        }
        var poptop;
        var bubbleleft;
        //Fix for defect #195790
        var scrollpos = calcScrollingPosition(contentwindow, thisdoc);
        var relobjpos = elepos[1] - scrollpos[1];
        var bubbleheight = bubble.offsetHeight;
        poptop = elepos[1] - 40;
        if (bubbleheight + relobjpos > viewportdem[1]) {
            var adjustment = viewportdem[1] - bubbleheight - relobjpos;
            poptop = poptop + adjustment;
        }
        bubbleleft = elepos[0] + bubble.element.clientWidth;
        if (bubbleleft + 380 > viewportdem[0]) {
            bubbleleft = elepos[0] - 390;
            if (bubbleleft <= 20) {
                bubbleleft = viewportdem[0] - 400;
            }
        }
        if (poptop < 10) {
            poptop = 10;
        }
        bubble.style.width = 380;
        bubble.style.top = parseInt(poptop) + 'px';
        bubble.style.left = parseInt(bubbleleft) + 'px';
    }
    var xmlhttp = initXMLHttp();
    xmlhttp.open("GET", bubble.controlurl);
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=utf-8"); // for post
    xmlhttp.onreadystatechange = function() {   // what to do when it succeeds or fails, don't really know
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            if (controlurl != bubble.controlurl) {  // arg!  times have changed and we must vamoos
                return;
            }
            if (count != bubble.count) {
                return;
            }
            var html = xmlhttp.responseText;
            var wholeresponse = html.indexOf("class=\"dialog\"");

            //var clouddem = getViewportSize(thisdoc);
            bubble.innerHTML = "";
            bubble.style.display = "inline";
            var focuser = new Focuser("focusitem1");
            focuser.SetIntervalID(setInterval(focuser.SetFocus, 2000));
            if (wholeresponse == -1) {
                html = "<div class='dialog'>";
                html += "<div class='content'>";
                html += "<div class='t'></div>";
                html += "<div class='r'>"
                if (bubble.delay == null || bubble.delay == 0) {
                    html += "<A HREF='javascript:void(0)' onclick='javascript:CloseControl(event);'><IMG SRC='images/bubble_x.gif' border='0' height='7' width='5' alt='" + ConfirmClose + "' title='" + ConfirmClose + "' onclick='javascript:CloseControl(true);'></A>"
                }
                html += "</div>";
                html += "<p class='hd'></p>";
                html += "<p><div class='b24-citations-content'>";
                html += xmlhttp.responseText;
                html += "</div></p>";
                html += "</div>";
                html += "<div class='b'><div></div></div>";
                html += "</div>";
            }
            bubble.innerHTML = html;
            bubble.style.display = 'inline';
            if (bubble.originalelement != null) {
                bubble.originalelement.style.cursor = "pointer";
            }
        }
        else if (xmlhttp.readyState == 4 && xmlhttp.status == 400) {
        }
        return;
    }
    xmlhttp.send();
   return;


}
function HighlightClick(event, hightlightID) {
    var element = null;
    if (event == null) {
        event = window.event;
    }
    if (event.target) {
        element = event.target;
    }
    else if (event.srcElement) {
        element = event.srcElement;
    }
    var oldHightlightone = document.getElementById(hightlightID);
    if (oldHightlightone !=null) {
    oldHightlightone.setAttribute("id",'');  // change the oldhighlightone into using original style
    }

    if (element != null) {
        var parent = element.parentNode;
        if (parent != null ) {
            parent.setAttribute("id",hightlightID)  // change the current click one into hightlight one
            }
    }
}
function RedisplayControl(event,controlid, controlurl, slider, sliderclass, howmany) {
    var element = null;
    if (event == null) {
        event = window.event;
    }
    if (event.target) {
        element = event.target;
    }
    else if (event.srcElement) {
        element = event.srcElement;
    }
    var control = null;
    if (element != null) {
        element.style.cursor = "wait";
        var parent = element.parentNode;
        while (parent != null && parent.nodeType == 1) {
            if (parent.getAttribute("id") == controlid) {
                control = parent;
                break;
            }
            parent = parent.parentNode;
        }
    }
    if (control == null) {
        control = document.getElementById(controlid);
    }
    if (control != null) {
        var xmlhttp = initXMLHttp();
        xmlhttp.open("GET", controlurl);
        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=utf-8"); // for post
        xmlhttp.onreadystatechange = function() {   // what to do when it succeeds or fails, don't really know
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                control.innerHTML = xmlhttp.responseText;
                if (slider != null && slider != "none") {
                    var delayedbubble;
                    if (slider == "right") {
                        delayedbubble = function() { SlideRight(control, sliderclass, howmany); };
                    }
                    else {
                        delayedbubble = function() { SlideLeft(control, sliderclass, howmany); };
                    }
                    slideToAHalt = true;
                    control.tovar = setInterval(delayedbubble, 60);
                }
            }
            else if (xmlhttp.readyState == 4 && xmlhttp.status == 400) {
            }
            return;
        }
        xmlhttp.send();
        return;
    }
}
function SlideRight(control, sliderclass,howmany) {
    var divlist = control.getElementsByTagName("div");
    var swappedone = false;
    var seen = 0;
    var nukeme = null;

    for (var i = 0; i < divlist.length; i++) {
        if (divlist[i].stophere != null) {
            break;
        }
        if (divlist[i].className == sliderclass && seen < howmany) {
            seen++;
            if (divlist[i].style.display != "none") {
                nukeme = divlist[i];
                swappedone = true;
                divlist[i].style.display = "none";
                for (var j = i + 1; j < divlist.length; j++) {
                    if (divlist[j].className == sliderclass && divlist[j].style.display == "none") {
                        divlist[j].style.display = "inline";
                        divlist[j].stophere = 1;
                        break;
                    }
                }
                break;
            }
        }
    }
    if (nukeme != null) {
        nukeme.parentNode.removeChild(nukeme);
    }
    if (!swappedone && control.tovar != null) {
        clearInterval(control.tovar);
        slideToAHalt = false;
        for (var i = 0; i < divlist.length; i++) {
            if (divlist[i].className == sliderclass && seen < howmany) {
                divlist[i].stophere = null;
            }
        }
    }
}
// scrolling left
// N hidden followed by M shown
// find rightmost hidden
// find first shown,  get rid of shown and show hidden
function SlideLeft(control, sliderclass, howmany) {
    var divlist = control.getElementsByTagName("div");
    var revealme = null;
    var seen = 0;
    var revealpoint = 0;
    // find left most
    for (var i = 0; i < divlist.length; i++) {
        if (divlist[i].className == sliderclass && seen < howmany) {
            seen++;
            if (divlist[i].style.display == "none") {
                divlist[i].stophere = true;
                revealme = divlist[i];
                revealpoint = i;
            }
        }
        if (seen >= howmany) {
            break;
        }
    }
    if (revealme == null) { // we're done
        slideToAHalt = false;
        clearInterval(control.tovar);
        for (var i = 0; i < divlist.length; i++) {
            if (divlist[i].className == sliderclass && seen < howmany) {
                divlist[i].stophere = null;
            }
        }
        return;
    }
    for (var i = divlist.length - 1; i >= revealpoint; i--) {
        if (divlist[i].className == sliderclass) { 
            if (divlist[i].style.display != "none") {
                if (divlist[i].stophere != null) {
                    break;
                }
                divlist[i].style.display = "none";
                divlist[i].parentNode.removeChild(divlist[i]);  // note that for IE, we have to actually remove the suckers  hiding fouls up for some reason
                break;
            }
        }
    }
    revealme.style.display = 'inline';
}
//=========================================================
function calcScrollingPosition(thewindow,doc) {
    var position = [0, 0];

    if (typeof thewindow.pageYOffset != 'undefined') {
        position = [
                        thewindow.pageXOffset,
                        thewindow.pageYOffset
            ];
    }

    else if (typeof doc.documentElement.scrollTop
             != 'undefined' && (doc.documentElement.scrollTop > 0 ||
                                doc.documentElement.scrollLeft > 0)) {
        position = [
                        doc.documentElement.scrollLeft,
                        doc.documentElement.scrollTop
            ];
    }

    else if (typeof doc.body.scrollTop != 'undefined') {
        position = [
                        doc.body.scrollLeft,
                        doc.body.scrollTop
            ];
    }

    return position;
}


//=========================================================
function calcViewportSize(thewindow, doc) {
    var size = [0, 0];

    if (typeof thewindow.innerWidth != 'undefined') {
        size = [
                    thewindow.innerWidth,
                    thewindow.innerHeight
            ];
    }
    else if (typeof doc.documentElement != 'undefined'
             && typeof doc.documentElement.clientWidth != 'undefined'
             && doc.documentElement.clientWidth != 0) {
        size = [
                    doc.documentElement.clientWidth,
                    doc.documentElement.clientHeight
            ];
    }
    else {
        size = [
                    doc.getElementsByTagName('body')[0].clientWidth,
                    doc.getElementsByTagName('body')[0].clientHeight
            ];
    }

    return size;
}

function RevealText(id, type) {
    var controlon = document.getElementById(id + '-' + type + 'on');
    var imgon = document.getElementById(id + "-toggleon");
    var imgoff = document.getElementById(id + "-toggleoff");
    var text = document.getElementById(id + '-' + type);
    if (text != null) {
        if (text.style.display == "none") {
            text.style.display = "inline";
            if (imgon != null) {
                imgon.style.display = "none";
                imgoff.style.display = "inline";
            }
        }
        else {
            text.style.display = "none";
            if (imgon) {
                imgon.style.display = "inline";
                imgoff.style.display = "none";
            }
        }
    }
    top.resizeCaller();
}
//
// turns the "more" for contentitems in peoplesearch into an iframe with navigation links
//
function ContentSearchMore(event, activityuri) {
    if (event == null) {
        event = window.event;
    }
    var e = event;
    var targ = null;
    if (e != null) {
        if (e.target) {
            targ = e.target;
        }
        else if (e.srcElement) {
            targ = e.srcElement;
        }
    }
    if (targ != null) {
        var ourdiv = null;
        var src = null;
        for (var i = 0; i < top.frames.length; i++) {  // are we already in a frame?
            var frame = top.frames[i];
            if (frame.document == document) { // yes.
                src = frame.location.href;
                var where = src.indexOf('?');
                if (where != -1) {  // normalize the source
                    src = src.substring(where);
                }
                break;
            }
        }
        if (src != null) {  // look for it in the array of iframes
            var frames = top.document.getElementsByTagName("iframe");
            for (var i = 0; i < frames.length; i++) {
                var iframe = frames[i];
                var isrc = iframe.src;
                var iwhere = isrc.indexOf('?');
                if (iwhere != -1) {  // normalize the iframe src
                    isrc = isrc.substring(iwhere);
                }
                if (isrc == src) {  // we have it, fix up our uri and change the iframe over
                    activityuri = activityuri.replace(/&amp;/g, "&")
                    activityuri = activityuri.replace(/&lt;/g, "<")
                    frames[i].src = activityuri;
                    return;
                }
            }
        }
        if (ourdiv == null) {  // we're not in an iframe, go up to our containing element
            var parent = targ.parentNode;
            while (parent != null && parent.className != "b24-activity-search") {
                parent = parent.parentNode;
            }
            ourdiv = parent;
        }
        if (ourdiv != null) {  // and blow in an iframe with our navigatable list
            ourdiv.className = "b24-activity-list";
            var now = new Date();
            var id = "ContentSearchMore" + now;
            ourdiv.innerHTML = "<iframe id='" + id + "' name='" + id + "'  src='" + activityuri + "' width='100%' height='100%' scrolling='no' frameborder='0' marginwidth='0' marginheight='0' class='b24-activity-search-iframe'><p>Your browser does not support iframes</p></iframe>";
            addIFrameId(id);
        }
    }
}
//
// shrink the contentitem iframe back to the 3 + a more link
//
function ContentSearchLess(event, activityuri) {
    var src = null;
    for (var i = 0; i < top.frames.length; i++) {  // always in an iframe
        var frame = top.frames[i];
        if (frame.document == document) {
            src = frame.location.href;
            var where = src.indexOf('?');
            if (where != -1) {
                src = src.substring(where);
            }
            break;
        }
    }
    var frames = top.document.getElementsByTagName("iframe");
    for (var i = 0; i < frames.length; i++) {  // find the iframe
        var iframe = frames[i];
        var isrc = iframe.src;
        var iwhere = isrc.indexOf('?');
        if (iwhere != -1) {
            isrc = isrc.substring(iwhere);
        }
        if (isrc == src) {  // fix the uri and change the iframe over
            activityuri = activityuri.replace(/&amp;/g, "&")
            activityuri = activityuri.replace(/&lt;/g, "<")
            iframe.src = activityuri;
            break;
        }        
    }
}

//
// recommend a note or comment
// 1 = yes, -1 = no, 0 = neither
//
function recommendContentItem(event, itemtype, itemid, targetid, yesno) 
{
    if (event == null) {
        event = window.event;
    }
    var e = event;
    var targ = null;
    if (e != null) {
        if (e.target) {
            targ = e.target;
        }
        else if (e.srcElement) {
            targ = e.srcElement;
        }
    }
    var parent = targ;
    if (targ != null) {
        parent = targ.parentNode;
        while (parent && parent.nodeType == 1 && parent.className.indexOf('n-control') != 0) {
            parent = parent.parentNode;
        }
        if (parent != null && parent.className.indexOf('n-control') == 0) {
            var choices = parent.getElementsByTagName("span");
            for (var i = 0; i < choices.length; i++) {
                var spanid = choices[i].getAttribute("id");
                if (spanid == "NOTERECOMMENDATION_UNSET") {
                    if (yesno == 0) {
                        choices[i].style.display = "inline";
                    }
                    else {
                        choices[i].style.display = "none";
                    }
                }
                else if (spanid == "NOTERECOMMENDATION_YES") {
                    if (yesno == 1) {
                        choices[i].style.display = "inline";
                    }
                    else {
                        choices[i].style.display = "none";
                    }
                }
                else if (spanid == "NOTERECOMMENDATION_NO") {
                    if (yesno == -1) {
                        choices[i].style.display = "inline";
                    }
                    else {
                        choices[i].style.display = "none";
                    }
                }
            }
        }
    }    
    var xmlhttp = initXMLHttp();
    var url = igeserviceroot;
    url += "?method=RateItem&id=" + itemid + "&value=" + yesno + "&targetid=" + targetid;
    xmlhttp.open("GET", url);
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=utf-8"); // for post
    xmlhttp.onreadystatechange = function() {   // what to do when it succeeds or fails, don't really know
    }
    if (igehasnotjoined) { // join them up and let them know the joy that awaits them
        JoinPrompt(parent, xmlhttp, null, false, JoinPromptRecommendContentItemThankyou, "OK");
        return;
    }
    else {
        xmlhttp.send(null);
    }
}

function RefreshBlock(event, id) {
    if (event == null) {
        event = window.event;
    }
    var e = event;
    var targ = null;
    if (e != null) {
        if (e.target) {
            targ = e.target;
        }
        else if (e.srcElement) {
            targ = e.srcElement;
        }
    }    
    var block = document.getElementById(id);
    if (block != null && block.RefreshBlock == null) {
        IGEInitializeNotesAndComments(block);
        block.RefreshBlock = block;
    }
    if (block != null && block.RefreshBlock != null) {
        block.RefreshBlock.CursorElement = targ;
        block.RefreshBlock.IGERefresh();
    }
}

// refresh a note or comment block
function NoteRefresh(ourelement) {
    if (ourelement.parentNode == null) {
        if (ourelement.RefreshInterval != null) {
            clearInterval(ourelement.RefreshInterval);
            ourelement.RefreshInterval = null;
        }
        return;
    }
    if (ourelement.RefreshStop != null && ourelement.RefreshStop) {   // its turned off (updating a comment or adding a new one for instance)
        return;
    }
    if (ourelement.RefreshWorking != null && ourelement.RefreshWorking) {  // we've come here a second time
        return;
    }
    var time = ourelement.getAttribute("threadmodifiedtime");  // the last time this note or comment was refreshed

    if (time != null) {
        if (ourelement.CursorElement != null) {
            ourelement.CursorElement.style.cursor = "wait";
        }
        var xmlhttp = initXMLHttp();
        var url = igeserviceroot;
        xmlhttp.open("POST", url, true);
        var params = "method=Refresh";
        var comment = this;
        if (ourelement.getAttribute("info") != null) {
            params += "&target=" + encodeURIComponent(ourelement.getAttribute("info"));  // where should we look for updates
        }
        if (ourelement.ContainerId != null) {
            params += "&locationid=" + ourelement.ContainerId;                           //   our guid
        }
        params += "&time=" + encodeURIComponent(time);
        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=utf-8"); // for post
        xmlhttp.onreadystatechange = function () {   // if there's a change we get back a 200 with the changed elements

          if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {  // get back our new/changed comments.  if there was no change it'll return a 304 and we won't come here
            if (ourelement.parentNode.style.display == "none") {
              ourelement.parentNode.style.display = "block";
            }
            var divlist = ourelement.getElementsByTagName("div");
            var notessection = null;
            var commentsection = null;
            var lastcomment = null;
            var firstnote = null;
            if (ourelement.className == "b24-notessection") {
              notessection = ourelement;
            }
            for (var i = 0; i < divlist.length; i++) {  // find the comment section and the last comment (its the blank form)
              var div = divlist[i];
              if (div.className == "b24-commentsection") {
                commentsection = div;
              }
              else if (div.className == "b24-comment") {
                lastcomment = div;
                var style = "" + div.getAttribute("style");
                if (style != null && style.indexOf("border-left") != -1) {
                  var where = style.indexOf("border-left");
                  style = style.substring(0, where);
                  div.setAttribute("style", style);
                }
              }
              else if (div.className == "b24-notessection") {
                notesection = div;
              }
              else if (div.className == "b24-note" && firstnote == null) {
                firstnote = div;
                var style = "" + div.getAttribute("style");
                if (style != null && style.indexOf("border-left") != -1) {
                  var where = style.indexOf("border-left");
                  style = style.substring(0, where);
                  div.setAttribute("style", style);
                }
              }
            }

            var temp = document.createElement("div");
            temp.innerHTML = xmlhttp.responseText;  // this has a structure like: <div "<div> - added notes </div><div> - new empty create note form </div>".  it contains new and changed comments
            if (temp.firstChild) {   // must slice out the new/changed comments and bung them in.
              ourelement.setAttribute("threadmodifiedtime", temp.firstChild.getAttribute("threadmodifiedtime"));
              var update = temp.firstChild.firstChild;
              while (update != null) {
                var next = update.nextSibling;
                if (update.nodeName.toLowerCase() == "div") {
                  var oldnote = document.getElementById(update.getAttribute("id"));
                  var mine = update.getAttribute("mine");
                  update.parentNode.removeChild(update);
                  if (oldnote != null) { // it was a modification    -- a real pain, merge in the changed text & dates
                    //                                oldnote.parentNode.replaceChild(update, oldnote);
                    var udivlist = update.getElementsByTagName("div");
                    var odivlist = oldnote.getElementsByTagName("div");
                    var otext = null;
                    var ocreatedate = null;
                    var omodifieddate = null;
                    var commentsClosed = false;
                    var justwhomp = true; // true if we can just replace the whole thing (no nested comments)
                    for (var od = 0; od < odivlist.length; od++) {
                      var odiv = odivlist[od];
                      if (odiv.className == "b24-commentsection" && odiv.style.display != "none") { // if the comment section is open, whomping is not OK.
                        justwhomp = false;
                        break;
                      }
                      else if (odiv.className == "n-text") {
                        otext = odiv;
                      }
                      else if (odiv.className == "n-creator") {
                        if (ocreatedate == null) {
                          ocreatedate = odiv;
                        }
                        else {
                          omodifieddate = odiv;
                        }
                      }
                    }
                    if (justwhomp) { // its ok just to replace the thing, no comments are attached.
                      oldnote.parentNode.replaceChild(update, oldnote);
                      /*                                    if (mine == null || mine.length == 0) {
                      var style = update.getAttribute("style");
                      if (style == null) {
                      style = "";
                      }
                      if (style.length > 0) {
                      style += ";";
                      }
                      style += "border-left-style:solid;border-left-width:3px";
                      update.setAttribute("style", style);
                      }
                      */
                    }
                    else {  // move the text and the dates into the displayed note.  NOTE that it should really do a better job.  Get the comments count too for instance.  This is what's easiest
                      /*                                    if (mine == null || mine.length == 0) {
                      var style = odiv.getAttribute("style");
                      if (style == null) {
                      style = "";
                      }
                      if (style.length > 0) {
                      style += ";";
                      }
                      style += "border-left-style:solid;border-left-width:3px";
                      odiv.setAttribute("style", style);
                      }
                      */
                      var seentext = false;
                      var seencreator = 0;
                      for (var ud = 0; ud < udivlist.length && seencreator < 2; ud++) {
                        var udiv = udivlist[ud];
                        if (udiv.className == "n-text") {
                          if (seentext) {
                            break;
                          }
                          seentext = true;
                          if (otext != null) {
                            otext.innerHTML = udiv.innerHTML;
                          }
                        }
                        else if (udiv.className == "n-creator") {
                          if (seencreator == 0 && ocreatedate != null) {
                            ocreatedate.innerHTML = udiv.innerHTML;
                          }
                          else if (seencreator == 1 && omodifieddate != null) {
                            omodifieddate.innerHTML = udiv.innerHTML;
                          }
                          seencreator++;
                        }
                      }
                    }
                  }
                  else if (update.className == "b24-note") {
                    /*
                    if (mine == null || mine.length == 0) {
                    var style = update.getAttribute("style");
                    if (style == null) {
                    style = "";
                    }
                    if (style.length > 0) {
                    style += ";";
                    }
                    style += "border-left-style:solid;border-left-width:3px";
                    update.setAttribute("style", style);
                    }
                    */
                    if (firstnote != null) {
                      firstnote.parentNode.insertBefore(update, firstnote);
                    }
                    else if (notessection != null) {
                      notessection.appendChild(update);
                    }
                    else if (commentsection != null) {
                      commentsection.appendChild(update);
                    }
                  }
                  else {
                    /*
                    if (mine == null || mine.length == 0) {
                    var style = update.getAttribute("style");
                    if (style == null) {
                    style = "";
                    }
                    if (style.length > 0) {
                    style += ";";
                    }
                    style += "border-left-style:solid;border-left-width:3px";
                    update.setAttribute("style", style);
                    }
                    */
                    if (lastcomment != null) {  // last comment is the empty form
                      lastcomment.parentNode.insertBefore(update, lastcomment);
                    }
                    else if (commentsection != null) {  // just tack it on, there's nothing else to do
                      commentsection.appendChild(update);
                    }
                  }
                  IGEInitializeNotesAndComments(update);  // for now.  will want to set some differently later maybe
                }
                update = next;
              }
            }
          }
          if (xmlhttp.readyState == 4) {  // turn refreshing back on
            if (ourelement.CursorElement != null) {
              ourelement.CursorElement.style.cursor = "pointer";
            }
          }
        }
        xmlhttp.send(params);  // talk to our master in userartifacts.aspx, using method Refresh
    }
}
var JoinPromptId = 0;
//
// our user hasn't joined and they're trying to do some community visible activity (like a public note)
// element is where on the screen, more or less, to show the bubble
// ajaxrequest is what to do on OK
// itsparams are what to feed the ajaxrequest
// performAnyway is what to do if they close and don't say "OK".  --- for notes we create anyhow, it'll be private
function JoinPrompt(element,ajaxrequest,itsparams,performFirst,bubbleText,BubbleButtonText) {
    if (element == null) {
        return false;
    }
    bubbleText = VariableSubstitute(bubbleText);
    if (bubbleText == null) {
        bubbleText = "Thanks for joining";
    }
    if (BubbleButtonText == null) {
        BubbleButtonText = "OK";
    }
    var thisdoc = document;
    var bubble = document.createElement("div");
    bubble = document.createElement("div");
    bubble.className = "b24-ingenius_bubble";
    bubble.id = "JoinPrompt" + JoinPromptId++;
    bubble.innerHTML = "";
    bubble.ajaxrequest = ajaxrequest;
    bubble.ajaxrequestparams = itsparams;
    if (performFirst) {
        PressGang(bubble);   // join them
    }
    document.body.appendChild(bubble);
    var elepos = getPosition(element);
    if (isIE) {  // is buggy
        var manageTitleDialog = document.getElementById("download");
        if ( manageTitleDialog != null && manageTitleDialog.style.display != "none")    {
            elepos[1] += 300;
        }
    }
    var viewportdem = getViewportSize(document);
    if (elepos[1] > 120) {
        bubble.style.top = parseInt(elepos[1] - 100) + "px";
    }
    else {
        bubble.style.top = parseInt(elepos[1]) + "px";
    }
    bubble.style.width = 420
    var bubbleleft = elepos[0];
    bubble.style.left = parseInt(bubbleleft) + "px";
    if (bubbleleft + 440 > viewportdem[0]) {
        bubble.style.left = parseInt(viewportdem[0] - 440) + "px";
    }
    if (elepos[1] + 300 > viewportdem[1]) {
        bubble.style.top = parseInt(elepos[1] - 300) + "px";
    }
    bubble.style.display = "inline";
    var closeImage = "images/button_close.gif";
    if (UserLanguage != null) {
        closeImage = "images/" + UserLanguage + "/button_close.gif";
    }
    var focuser = new Focuser("focusitem1");
    focuser.SetIntervalID(setInterval(focuser.SetFocus, 2000));
    var html = "<div class='dialog' style='position:relative;z-index:1004'>";
    html += "<div class='content'>";
    html += "<div class='t'></div>";
    html += "<div class='r'><A HREF='javascript:void(0)' onclick='JoinPromptClose(\"" + bubble.id + "\")'><IMG SRC='images/bubble_x.gif' border='0' height='7' width='5' alt='Do Not Join' title='Do Not Join' onclick='JoinPromptClose(\"" + bubble.id + "\")'></A></div>";
    html += "<div>&nbsp;</div>";
    html += "<p class='hd' style='text-align:center;padding-top:10px;margin-top:10px'>";
    html += bubbleText;
    html += "</p>";
    html += "<p><div class='b24-citations-content'>";
    html += "<p style='text-align:center'><img src='images/bubble_ingenius.gif'></p>";
    html += "<p style='text-align:center;margin:5px;padding:5px;'>" + VariableSubstitute(JoinPromptBoilerPlate) + "</p>";
    html += "<p class='join-close'><a class='n-control-link' onclick='JoinPromptClose(\"" + bubble.id + "\");'><img src='"  + closeImage + "' height='13' width='46' alt='Close' title='Close'></img></a></p>";
    html += "</p>";
    html += "<div style='float:left' class='join-infolinks'><a href='./myprofile.aspx' target='_blank' class='join-infolink'>" + JoinPromptProfileLink + "</a></div><div style='float:right'> <a href='http://documentation.skillsoft.com/bkb/30372.htm' target='_blank' class='join-infolink'>" + JoinPromptHelpLink + "</a></div>";
    html += "<p>&nbsp;</p>";
    html += "</div></p>";
    html += "</div>";
    html += "<div class='b'><div>&nbsp;</div></div>";
    html += "</div>";
    bubble.innerHTML = html;

    if (!performFirst) {
        PressGang(bubble);   // join them
    }
}

// glory be, they've agreed to join.  
// we get the bubble, do the joining, add a join anchor so they won't be bugged again, and then execute the bubble ajax.
function JoinPromptAgree(id) {
    var bubble = document.getElementById(id);
    if (bubble != null) {
        bubble.style.display = "none";
        PressGang(bubble);
        bubble.parentNode.removeChild(bubble);
    }
}

// join them up
function PressGang(bubble) {
    igehasnotjoined = false;  // hurray!  they're a happy member of the community
    var xmlhttp = initXMLHttp();
    var url = igeserviceroot + "?method=Join";
    xmlhttp.open("GET", url, true);
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=utf-8"); // for post
    xmlhttp.onreadystatechange = function() {   // if there's a change we get back a 200 with the changed elements
        if (xmlhttp.readyState == 4) {
            if (bubble != null) {
                if (bubble.ajaxrequest != null) {
                    bubble.ajaxrequest.send(bubble.ajaxrequestparams);
                }
            }
        }
    }
    xmlhttp.send(null);
}


function JoinPromptClose(id) {
    var bubble = document.getElementById(id);
    if (bubble != null) {
        bubble.style.display = "none";
        bubble.parentNode.removeChild(bubble);
        if (bubble.performAnyway) {
        }
        location.reload(true);
    }
}

