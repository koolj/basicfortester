var serviceroot = "/AjaxServices/UserArtifacts.aspx";
if (isDev) {
    serviceroot = "./AjaxServices/UserArtifacts.aspx";
}
  //============================================================
function Expand(bid, cid, lowrowid, justthisrowid) {
    var thisdoc = document;
    //Fix for defect #195790
    var contentframe = null;
    contentframe = SetContentFrame();
    var framed = false;
    if (contentframe != null) {
        framed = true;
        thisdoc = contentframe.document;
    }
    var url = serviceroot; //"data.asp";

    var onToc = false; // on toc page
    var onView = false; // on viewer page
    if (thisdoc.getElementById("ContentPage")) {
        onView = true;
    }
    var tocannowrapperid = null; // CBM0 -- on toc page
    var cstable = null;
    var tableid = null;
    var param = "&bookid=" + bid + "&chunkid=" + cid;
    var tocTableid = "toc" + bid;
    if (lowrowid==null && cid !=0) {   // it's a chapter twistie
        //param = "?svc=3" + param; // for get
        param = "method=TOCChapter" + param; // for post
        tableid = "CS"+cid;
    }
    else {   // it's an annotation - maybe in the toc or the content
        param = "method=NonIGEViewerNote&bookid=" + bid + "&chunkid=" + cid + "&HowMany=5";
        if (!onView) {
            onToc = true;
	    param += "&toc=1";  // have to know if its the toc,  there's more than 1 chunk per chapter and all the notes in a chapter get listed
        }        
        // param = "?svc=annlist" + param;   // for get
        tableid = "ANN" + cid;
        tocannowrapperid = "CBM" + cid;
        if (onView) {  // it's in the content, only want this rowid.
            /* don't highlight at the moment 
            var target = document.getElementById(lowrowid);
            if (target != null) {
                setAnnotationSelectedParaStyle(target);
            }
            */
            tableid += "-" + lowrowid;
            param += "&elementid=" + lowrowid;
            param += "&data=viewer";
        }
        else {
            param += "&data=other";
         }
    }
    cstable = document.getElementById(tableid);

    var twistieTarget = "C" + cid;
    if (lowrowid != null && (justthisrowid || onToc)) {
        twistieTarget += "-" + lowrowid;
    }
    var twistieImgId = "twist" + cid;
    if (lowrowid != null && (justthisrowid || onToc)) {
        twistieImgId += "-" + lowrowid;
    }

    var img1 = document.getElementById(twistieImgId + "-closed");
    var img2 = document.getElementById(twistieImgId + "-working");
    var img3 = document.getElementById(twistieImgId + "-open");
    
    if(cstable == null)     {
        if (img1 != null) {
            img1.style.display = 'none';
        }
        if (img2 != null) {
            img2.style.display = 'inline';
        }
        if (img3 != null) {
            img3.style.display = 'none';
        }
        //      window.frames["dataframe"].location.href = "data.asp"+param;
        xmlrequest = initXMLHttp();
        //        xmlrequest.open("GET", url + "?" + param);  // for get

        xmlrequest.open("POST", url, true); // for post
        xmlrequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded, charset = ISO-8859-1"); // for post
        xmlrequest.setRequestHeader("Content-length", param.length); // for post
        xmlrequest.setRequestHeader("Connection", "close"); // for post

        //                  alert("beforefunction");
        xmlrequest.onreadystatechange = function() {
            if (xmlrequest.readyState == 4 &&
              xmlrequest.status == 200) {
                  //                  alert("infunction");
                InsertCT(twistieTarget, xmlrequest.responseText);
                // --- if there is no anno in the anno section delete annotation title
                if (onToc) {
                    cstable = thisdoc.getElementById(tableid);
                    annoTable = thisdoc.getElementById(tocannowrapperid);
                    tocTable = thisdoc.getElementById(tocTableid);
                    var d = getElementsByAttributeName(thisdoc, 'table', 'CBM0', 'id');
                    if (cstable) {
                    }
                    else {
                        // if in this annotation section there is no more anotation, delete the whole annotation sec 
                        if (cstable == null && annoTable && annoTable.parentNode) {
                            old = (annoTable.parentNode).removeChild(annoTable);
                        }
                        var browser = navigator.appName
                        if (browser == "Microsoft Internet Explorer") {

                            if (d && d[0]) {
                                old = (d[0].parentNode).removeChild(d[0]);
                            }
                            else {
                                // in the case when the anno is fist time added onto toc page, IE has problem to catch dynamically generated table CBM0
                                // so we have to find the tocTable and remove its first child to remove annotation section
                                // note here: if toc structure changes, it will affect the code's function
                                if (tocTable) {
                                    var tocTbody = tocTable.firstChild; // this is tbody
                                    var deltr = tocTbody.firstChild;// annotation
                                    tocTbody.removeChild(deltr);
                                }
                            }
                        }

                    }
                }
                if (onView) {
                    cstable = document.getElementById(tableid);
                    // find the div like <div class="b24-annotation" locator="bookmarkchapter.4FCDDE9C-68F3-4864-A5A8-0D8A20EB21BD">
                    var divlocatorId = "bookmark" + lowrowid;
                    annodiv = getElementsByAttributeName(document, 'div', divlocatorId, 'locator');
                    if (cstable)
                    { }
                    else if (annodiv) {
                        // if in this annotation section there is no more anotation, delete the whole annotation sec 
                        if (annodiv && annodiv[0] && annodiv[0].parentNode) {
                            var myWrapper = annodiv[0].parentNode;
                            old = (annodiv[0].parentNode).removeChild(annodiv[0]);
                            while (myWrapper != null && myWrapper.className != "b24-annotationsinline") {  // work back up to it
                                myWrapper = myWrapper.parentNode;
                            }
                            if (myWrapper != null) {
                                if (myWrapper.childNodes.length == 0) {
                                    myWrapper = myWrapper.parentNode;
                                    if (myWrapper != null && myWrapper.className == "b24-annotation_wrapper") {
                                        var myContent = myWrapper.firstChild;  // first child is our real content.
                                        myWrapper.removeChild(myContent);      // take it and put it
                                        myWrapper.parentNode.insertBefore(myContent,myWrapper);   // up a notch (just before the wrapper
                                        myWrapper.parentNode.removeChild(myWrapper);  // remove the annotation wrapper.  wipe the sweat from our brow and be thankful.
                                    }
                                }
                            }
                        }
                        // update the toc menu and notes menu
                        UpdateTocAndNotesMenu();
                    }                    
                }
                //-- end of delete annotation title action               
            }
            if (xmlrequest.readyState == 4 &&
              xmlrequest.status == 403) {
                  //                  alert("error");
                if (xmlrequest.responseText.indexOf("errorcode='1'") != -1) {
                    window.location.reload();
                }
                else if (xmlrequest.responseText.indexOf("errorcode=\"1\"") != -1) {
                    window.location.reload();
                }
                else if (xmlrequest.responseText.indexOf("errorcode=1") != -1) {
                    window.location.reload();
                }
                else {
                    InsertCT(twistieTarget, xmlrequest.responseText);
                }
            }
        }
        //        xmlrequest.send(null);  // for get
        xmlrequest.send(param);   // for post
    }
    else  {
        if (cstable.openstyle != null) {
            cstable.style.display = cstable.openstyle;
        }
        else {
            cstable.style.display = 'inline';
        }
        img1.style.display = 'none';
        img2.style.display = 'none';
        img3.style.display = 'inline';
    }
    //      if(cbmtable)
    //    cbmtable.style.display = 'none' 
}  
  //============================================================
function ListExpand(bid,fixrowspan) {
    if (fixrowspan == null) {
        fixrowspan = false;
    }
    var cstable = null;   
  //  var param = "?svc=annlist"; // for get
    var param = "method=NonIGENoteList";  //"svc=annlist";  // for post
    cstable = document.getElementById("ANN"+bid);
    var twistieTarget = "C" + bid;
    var twistieImgId = "twist" + bid;
    
    var img1 = document.getElementById(twistieImgId + "-closed");
    var img2 = document.getElementById(twistieImgId + "-working");
    var img3 = document.getElementById(twistieImgId + "-open");
    
    if(cstable == null)     {
        img1.style.display = 'none';
        img2.style.display = 'inline';
        img3.style.display = 'none';
        param += "&bookid=" + bid;
//      window.frames["dataframe"].location.href = "data.asp"+param;
        xmlrequest = initXMLHttp();
        var url = serviceroot; // "data.asp";                              // for post
        //        xmlrequest.open("GET", url + "?" + param);  // for get
      // using xmlhttprequest post method
        
      xmlrequest.open("POST", url, true);      // for post
      xmlrequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded"); // for post
      xmlrequest.setRequestHeader("Content-length", param.length); // for post
      xmlrequest.setRequestHeader("Connection", "close"); // for post
        
      xmlrequest.onreadystatechange = function() {
      if (xmlrequest.readyState == 4 &&
              xmlrequest.status == 200) {
          if (fixrowspan) {
              var rowspantd = document.getElementById("ROWSPANTD" + bid);
              if (rowspantd) {
                  var span = rowspantd.rowSpan;
                  if (span && !isNaN(span)) {
                      rowspantd.rowSpan = span + 1;
                  }
              }
          }
          InsertCT(twistieTarget, xmlrequest.responseText);
          cstable = document.getElementById("ANN" + bid);
          var annoTR = document.getElementById(twistieTarget);
          if (cstable) {
          }
          else {
              // if in this annotation section there is no more anotation, delete the whole annotation sec
              if (cstable == null && annoTR && annoTR.parentNode) {
                  old = (annoTR.parentNode).removeChild(annoTR);
              }

          }
              // update the toc menu and notes menu
              UpdateTocAndNotesMenu();
              }
              if (xmlrequest.readyState == 4 &&
              xmlrequest.status == 403) {
                  if (xmlrequest.responseText.indexOf("errorcode='1'") != -1) {
                      window.location.reload();
                  }
                  else if (xmlrequest.responseText.indexOf("errorcode=\"1\"") != -1) {
                      window.location.reload();
                  }
                  else if (xmlrequest.responseText.indexOf("errorcode=1") != -1) {
                      window.location.reload();
                  }
                  else {
                      InsertCT(twistieTarget, xmlrequest.responseText);
                  }
              }
        }
      //        xmlrequest.send(null); // for get
        xmlrequest.send(param); // for post
    }
    else  {
        if (cstable.openstyle != null) {
            cstable.style.display = cstable.openstyle;
        }
        else {
            cstable.style.display = 'inline';
        }
        img1.style.display = 'none';
        img2.style.display = 'none';
        img3.style.display = 'inline';
    }
}  

//ajaxly edit and delete annotation
function manageAnno(action,bookmarkid, bookid, chunckid,rowid,elementid)
{
    var framed = false;
    var thisdoc = document;
    var tocdoc = document;
    //Fix for defect #195790
    var contentframe = null;
    contentframe = SetContentFrame();
    if (contentframe != null) {
        framed = true;
        thisdoc = contentframe.document;
        var tocframe = top.frames["Toc"];
        if (tocframe) {
            tocdoc = tocframe.document;
        }
    }


    // first, figure out this call coming from which page: bookshelf, toc, or viewer 
    var onToc = false;
    var onView = false;
    var onBookshelf = false;

    if (thisdoc.getElementById("ContentPage")) {
        onView = true;
    }

    var tableid = null;
    var tocannoid = null;
    var tocannowrapperid = null;
    var viewerannoid = null;
    var bookshelfannoid = null;
    
    if (rowid==null) {   // it's a chapter twistie
        tableid = "CS"+chunckid;
        }
    else {   // it's an annotation - maybe in the toc or the content
        tableid = "ANN" + chunckid;
        bookshelfannoid = "ANN" + bookid;
        tocannowrapperid = "CBM" +chunckid;
        }
    tocannoid = tableid;
    if (elementid)
    {
        viewerannoid = tableid + "-" + elementid;
      //  param += "&data=" + elementid;
    }
    cstable = document.getElementById(tableid);
    var empty = false;
    var annotationParent = null;
    var annotationTarget = document.getElementById("annbmkid" + bookmarkid);
    if (annotationTarget != null && action == 'delete') {
        var parent = annotationTarget.parentNode;        
        annotationParent = parent.parentNode;
        annotationTarget.innerHTML = "";
        empty = true;
        for (var i = 0; i < parent.childNodes.length; i++) {
            var n = parent.childNodes[i];
            if (n.childNodes.length > 0) {
                empty = false;
                break;
            }
        }
        if (empty) {
            parent.innerHTML = "";
            parent.style.display="none";
            while (parent && !(parent.className == 'b24-annotation' || parent.className == 'b24-annotation-show')) {
                parent = parent.parentNode;
            }
            if (parent) {
                parent.innerHTML = "";
                parent.style.display="none";
                if (onView) {
                    while (parent && parent.className != "b24-annotation_wrapper") {
                        parent = parent.parentNode;
                    }
                    if (parent) {
                        parent.className = "";
                    }
                }
            }            
            else {
                var heading = document.getElementById("C" + bookid);
                if (heading) {
                    heading.style.display="none";
                }
            }
        }
    }
    else if (annotationTarget != null && action == 'update') {
        var labelnode = document.getElementById("bmklabl2");
        var corpnotenode = document.getElementById("cn2");
        var textnode = document.getElementById("bmknote");
        var note = "";
        var label = "";
        var isCorpNote = false;
        if (textnode != null) {  // fix our text 
            note = textnode.value;
        }
        if (labelnode != null) {
            label = labelnode.value;
        }
        if (corpnotenode != null) {
            isCorpNote = corpnotenode.checked;
        }
        var child = annotationTarget.firstChild;
        var lastchild = child;
        var foundTextNode = false;
        var titleNode = null;
        while (child) {
            if (child.className=="b24-annotationtoctitle") {
                titleNode = child;
                if (child.innerText) {  // update and existing node
                    child.innerText = label;
                }
                else {
                    child.textContent = label;
                }
            }
            else if (child.className=="b24-annotationtoctext") {
                foundTextNode = true;
                if (child.innerText) {  // update and existing node
                    child.innerText = note;
                }
                else {
                    child.textContent = note;
                }
            }
            else if (child.className=="b24-annotationtocfooter") {
                var imglist = child.getElementsByTagName("IMG");
                if (imglist != null && imglist.length > 0) {
                    if (isCorpNote) {
                        imglist[0].style.display="inline";
                    }
                    else {
                        imglist[0].style.display="none";
                    }
                }
                var alist = child.getElementsByTagName("a");
                if (alist != null && alist.length > 0) {
                    var a = alist[0];
                    var href = a.href;
                    var end = href.indexOf(')');
                    if (end != -1) {
                        if (isCorpNote) {
                            href = href.substring(0,end - 1) + '1' + href.substring(end);
                        }
                        else {
                            href = href.substring(0,end - 1) + '0' + href.substring(end);
                        }
                        a.href = href;
                    }
                }
            }
            lastchild = child;
            child = child.nextSibling;
        }
        if (!foundTextNode) { // must add in a text node
            var bmktextelm = document.createElement('div');
            bmktextelm.className = "b24-annotationtoctext";
            var browser = navigator.appName;
            
            if (browser == "Microsoft Internet Explorer") {
                bmktextelm.innerHTML = "<span><span>" + note + "</span><img src='images/_.gif' border='0' height='8' width='8'/></span>";
            }
            else {
                if (bmktextelm.innerText) {
                    bmktextelm.innerText = note;
                }
                else {
                    bmktextelm.textContent = note;
                }
            }
            annotationTarget.insertBefore(bmktextelm,lastchild);
        }
    }

    
    // xmlhttprequest call
    var param = "task=" + action ;
    param += collectParamsForTitle();
    if (bookmarkid) param += "&bmkid=" + bookmarkid;
    var bmlabel = document.getElementById("bmklabl2");
    if (bmlabel) {
        var lbl = htmlEncode(bmlabel.value);
        param += "&bmklabl=" + escape(lbl);
    }
    
    
    var booknote = document.getElementById("bmknote");
    var corpnote = document.getElementById("cn2");
    if (corpnote && corpnote.checked) param += "&cn=" + corpnote.value;
    
    if (booknote)
    {
        var notes = htmlEncode(booknote.value);
        notes = escape(notes);  // use encodeURIComponent to retrieve textarea 
        if (notes) param +="&bmknote=" + notes;
    }

 //   var dataSource = "bookmark.asp?" + param;
    var url = "annotation.asp";
    xmlrequest =  initXMLHttp();
 // xmlrequest.open("GET", dataSource);
    xmlrequest.open("POST", url, true);
    xmlrequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=utf-8"); // for post

    xmlrequest.onreadystatechange = function() {
        if (xmlrequest.readyState == 4 &&
            xmlrequest.status == 200) {
            // update the toc menu and notes menu
            UpdateTocAndNotesMenu();
        }
    } // end of function
        //    xmlrequest.send(null);
    param="function=ManageAnno&" + param;
    xmlrequest.send(param);
    SunDown();
}

// after create annotation, show annotation div at the proper place
function ShowAnnotation(bookmarkid,bookid,chunkid,rowid,elementId) {

    var thisdoc = document;
    var navbardoc = document;
    var tocdoc = document;
    //Fix for defect #195790
    var contentframe = null;
    contentframe = SetContentFrame();
    var framed = false;
    if (contentframe != null)
        {
            framed = true;
            thisdoc = contentframe.document;
            var navbarframe = top.frames["Navbar"];
            if (navbarframe) {
                navbardoc = navbarframe.document;
            }
            var tocframe = top.frames["Toc"];
            if (tocframe != null) {
                tocdoc = tocframe.document;
            }
        }
    var buttonCreate = thisdoc.getElementById("btCreateBookmark");
    if (buttonCreate) {
        buttonCreate.disabled = true;
        buttonCreate.style.cursor = "wait";
    }
    
    var param = "task=add&mode=ajaxbookmark";
    if (bookmarkid) { 
        param = "task=update&mode=ajaxbookmark&bmkid="+ bookmarkid;
    }
    param += collectParamsForTitle();

    //if (bookmarkid) param +="&bmkid=" + bookmarkid;
    if (bookid) param +="&bkid=" + bookid;
    if (chunkid)   {
        param += "&chnkid=" +chunkid ;
    }
    else   {
        param += "&chnkid=0" ;
    }
    // if (rowid) param += "&rowid=" +rowid; 
    // if (elementId) param += "&elementid=" +elementId; 
    var corpnote = document.getElementById("cn2");
    if (corpnote && corpnote.checked) param+="&cn=" + corpnote.value;
    var booknote = document.getElementById("bmknote");  
    var bmrowid = document.getElementById("rowid");
    var bmelementid = document.getElementById("elementid");
    if (bmelementid && bmrowid && bmrowid.value == 0) {
        bmelementid.value = 'ContentPage';
    }
    var bmlabel = document.getElementById("bmklabl2");
    if (bmlabel) {
        var lbl = htmlEncode(bmlabel.value);
        param += "&bmklabl=" + escape(lbl);
    }

    if (bmrowid) {
        param += "&destid=" +bmrowid.value; 
    }

    if (bmelementid) {
        param += "&elementid=" +bmelementid.value;
    }
    else  {
        param += "&elementid=0"; 
    }

    if (booknote) {
        var notes = htmlEncode(booknote.value);
        notes = escape(notes);  // use encodeURIComponent to retrieve textarea 
        if (notes) param +="&bmknote=" + notes;
    }
  
    //window.frames["dataframe"].location.href = "data.asp"+param;
    var dataSource = "annotation?" + param;
    var url = "annotation.asp";
    xmlrequest =  initXMLHttp();
    //xmlrequest.open("GET", dataSource);
    xmlrequest.open("POST", url, true);
    xmlrequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=utf-8"); // for post
    xmlrequest.setRequestHeader("Content-length", param.length); // for post
    xmlrequest.setRequestHeader("Connection", "close"); // for post
    xmlrequest.onreadystatechange = function() {
        if (xmlrequest.readyState == 4 &&
            xmlrequest.status == 200) {
                var annoHTML = xmlrequest.responseText;
                if (annoHTML.indexOf("<HTML") == 0) {
                    window.location.reload();
                    SunDown();
                    return;
                }
                var i_bookIcon = document.getElementById("64");
                if (i_bookIcon) {
                    i_bookIcon.style.display="inline";
                }
                var toggleToolAddBook = navbardoc.getElementById("BrowseToolFolderId" + bookid);
                if (toggleToolAddBook) {
                    toggleToolAddBook.style.display="none";
                    toggleToolAddBook.parentNode.style.display="none";
                }
                var toggleToolManageBook = navbardoc.getElementById("BrowseToolManageBookId" + bookid);
                if (toggleToolManageBook) {
                    toggleToolManageBook.style.display="inline";
                    toggleToolManageBook.parentNode.style.display="inline";
                }
                if (bmelementid) {
                    // add content level annotation at viewer.asp 
                    var arrAnnoDivs = getElementsByClassName(document, 'div', 'b24-annotation');
                    var insertAnnoDiv = true;
                    for (var i = 0; i < arrAnnoDivs.length; i++) {
                        var annoDiv = arrAnnoDivs[i];
                        var target = annoDiv.getAttribute("LOCATOR");
                        if (target != null && target.indexOf("bookmark") != -1) {
                            target = target.substring(8);
                            if (target == bmelementid.value) {
                                insertAnnoDiv = false;
                                if (annoDiv && annoDiv.parentNode) {
                                    // if on the viewer page, there is already div for anno, delete it
                                    annoDiv.parentNode.removeChild(annoDiv);
                                }
                            }
                        }
                    }



                    var myElement = document.createElement('div');
                    myElement.innerHTML = annoHTML;
                    var properplace;


                    properplace = thisdoc.getElementById(bmelementid.value);
                    if (properplace == null)
                    {
                        properplace = thisdoc.getElementById('ContentPage');
                        if (properplace == null) {
                            if (framed) {
                                contentframe.location.reload();
                            }
                            else {
                                top.location.reload();
                            }
                        }
                    }
                    if (properplace != null && annoHTML != null) { // first time to add anno to this element area
                        var myWrapper = null;
                        if (properplace.parentNode.className == "b24-annotation_wrapper") {
                            myWrapper = properplace.parentNode;
                        }
                        else {
                            var nname = "div";
                            if (properplace.nodeName.toLowerCase() == "caption") {
                                nname = "caption";
                            }
                            myWrapper = document.createElement(nname);  // make the box to hold it
                            myWrapper.className="b24-annotation_wrapper";
                            properplace.parentNode.insertBefore(myWrapper,properplace);  // get our box into the content just before our annotated content
                            properplace.parentNode.removeChild(properplace);   // remove our content
                            myWrapper.appendChild(properplace);  // put our content into our box
                        }
                        myWrapper.appendChild(myElement);    // add in the annotation twistie
                    }
                    Expand(bookid, chunkid, bmelementid.value, 1);

                    if (framed) {  // don't disrupt frameless because of this, otherwise reload left hand nav to get our annotation list
                        tocframe.location.reload();
                    }
                    SunDown();
                    // update the toc menu and notes menu
                    UpdateTocAndNotesMenu();
                }
                else {
                    // add toc level annotation at toc.asp 
                    var tocTable = thisdoc.getElementById("VideoAnnotationAnchor");
                    if (tocTable ==  null) {
                        tocTable = thisdoc.getElementById("TOCAnnotationAnchor");
                    }
                    var arrAnnoTable = thisdoc.getElementById('CBM0');
                    var arrAnnoContentTable = thisdoc.getElementById('ANN0');
                    if (arrAnnoTable || arrAnnoContentTable) {
                        // there are existing anno
                        //                var newTr = document.createElement('tr'); 
                        //                newTd = document.createElement('td'); 
                        //                var annoHTML = xmlrequest.responseText;
                        //                newTd.innerHTML = annoHTML;
                        //               // var cellText = document.createTextNode(annoHTML);
                        //                //newTd.appendChild(cellText);
                        //                newTr.appendChild(newTd);
                        //                arrAnnoTable.appendChild(newTr);
                        if (arrAnnoContentTable) {
                            var parentNode = arrAnnoContentTable.parentNode;
                            if (parentNode)
                                parentNode.removeChild(arrAnnoContentTable);
                        }
                        Expand(bookid, 0, 0);
                        SunDown();
                    }
                    else {
                        // there is no existing anno
                        var myElement = document.createElement('div');
                        myElement.className="b24-annotation-show";
                        var bookMarkTable = "<table CELLSPACING='0' CELLPADDING='0' BORDER='0' WIDTH='100%' Id='CBM0'>";
                        bookMarkTable += "<tbody>";
                        bookMarkTable += "<tr id='C0-0'>";
                        bookMarkTable += "<td>";
                        var endBookMarkTable = "</td></tr></tbody></table>";
                        myElement.innerHTML = bookMarkTable + annoHTML + endBookMarkTable;
                        tocTable.parentNode.insertBefore(myElement,tocTable);
                        Expand(bookid, 0, 0);
                        SunDown();
                    }
                }
            }
        if (xmlrequest.readyState == 4 &&
            xmlrequest.status == 403) {
                if (xmlrequest.responseText.indexOf("errorcode='1'") != -1) {
                    top.location.reload();
                }
                else if (xmlrequest.responseText.indexOf("errorcode=\"1\"") != -1) {
                    top.location.reload();
                }
                else if (xmlrequest.responseText.indexOf("errorcode=1") != -1) {
                    top.location.reload();
                }
                else {

                }
            }
    }
    // xmlrequest.send(null);
    param = "function=ShowAnnotation&" + param;
    xmlrequest.send(param);
    // document.getElementById('download').style.display='none';
}

function UpdateTocAndNotesMenu() {

    var tocUpdateLinkButtonId = document.getElementById("tocUpdateLinkButtonId");

    if (tocUpdateLinkButtonId != null)
        __doPostBack(tocUpdateLinkButtonId.value, '');
}
//
// handle the quick bookmark
//
function QuickBookmarkNavbar(event,bookid,chunkid,on) {
    if (event == null) {
        event = window.event;
    }
    var e = event;
    var targ = null;
    if (e != null) {
        if (e.target) {
            targ = e.target;
        }
        else if (e.srcElement) {
            targ = e.srcElement;
        }
    }
    if (targ == null) {
        return;
    }
    //
    // first fire off the ajax
    var dataSource =  "annotation.asp?task=";
    if (on == 1) {
        dataSource += "add";
    }
    else {
        dataSource += "delete";
    }
    dataSource += "&bookid=" + bookid + "&chunkid=" + chunkid;
    XMLHttpRequestObject.open("GET", dataSource);
    
    XMLHttpRequestObject.onreadystatechange = function() { // don't care
        if (XMLHttpRequestObject.readyState == 4 &&
            XMLHttpRequestObject.status == 200) {        
                if (XMLHttpRequestObject.responseText.indexOf("b24-loginbody") > -1) {
                   top.location.reload();
                   return;
                }
                //
                // now worry about the display
                //
                //
                var toggleonimg = null;
                var toggleoffimg = null;
                var parent = targ.parentNode.parentNode;
                var links = parent.getElementsByTagName("a");
                for (var i = 0; i < links.length; i++) {
                    if (links[i].getAttribute("id") == "isquickbookmarknb") {
                        toggleonimg = links[i];
                    }
                    else if (links[i].getAttribute("id") == "isnotquickbookmarknb") {
                        toggleoffimg = links[i];
                    }
                }
                if (toggleonimg && toggleoffimg) {
                    if (on == 1) {
                        toggleonimg.style.display='inline';
                        toggleoffimg.style.display = 'none';
                    }
                    else {
                        toggleonimg.style.display='none';
                        toggleoffimg.style.display = 'inline';
                    }
                }
                var framed = false;
                var thisdoc = document;
                var navbardoc = document;
                var tocdoc = document;
                //Fix for defect #195790
                var contentframe = null;
                contentframe = SetContentFrame();
                if (contentframe != null) {
                    framed = true;
                    thisdoc = contentframe.document;
                    var navbarframe = top.frames["Navbar"];
                    if (navbarframe) {
                        navbardoc = navbarframe.document;
                    }
                    var tocframe = top.frames["Toc"];
                    if (tocframe != null) {
                        tocdoc = tocframe.document;
                    }
                }
                var i_bookIcon = thisdoc.getElementById("64");
                if (i_bookIcon) {
                    i_bookIcon.style.display="inline";
                }
                var toggleToolAddBook = navbardoc.getElementById("BrowseToolFolderId" + bookid);
                if (toggleToolAddBook) {
                    toggleToolAddBook.style.display="none";
                    toggleToolAddBook.parentNode.style.display="none";
                }
                var toggleToolManageBook = navbardoc.getElementById("BrowseToolManageBookId" + bookid);
                if (toggleToolManageBook) {
                    toggleToolManageBook.style.display="inline";
                    toggleToolManageBook.parentNode.style.display="inline";
                }
                toggleonimg = thisdoc.getElementById("isquickbookmark");
                toggleoffimg = thisdoc.getElementById("isnotquickbookmark");
                if (toggleonimg) {
                    if (on == 1) {
                        toggleonimg.style.display='inline';
                    }
                    else {
                        toggleonimg.style.display='none';
                    }
                }
                if (toggleoffimg) {
                    if (on == 1) {
                        toggleoffimg.style.display = 'none';
                    }
                    else {
                        toggleoffimg.style.display = 'inline';
                    }
                }
                if (framed) {
                    tocframe.location.reload();  // remember to handle the toc redisplay
                }
                // update the toc menu and notes menu
                UpdateTocAndNotesMenu();
            }
        else if (XMLHttpRequestObject.readyState == 4 &&
                 XMLHttpRequestObject.status == 403) {
                    top.location.reload();
                }
    }
    XMLHttpRequestObject.send(null);


}

function QuickBookmark(bookid,chunkid,on) {
    var dataSource =  "annotation.asp?task=";
    if (on == 1) {
        dataSource += "add";
    }
    else {
        dataSource += "delete";
    }
    dataSource += "&bookid=" + bookid + "&chunkid=" + chunkid;
    XMLHttpRequestObject.open("GET", dataSource);

    XMLHttpRequestObject.onreadystatechange = function() { // don't care
        if (XMLHttpRequestObject.readyState == 4 &&
            XMLHttpRequestObject.status == 200) {        
                var toggleonimg = document.getElementById("isquickbookmark");
                var toggleoffimg = document.getElementById("isnotquickbookmark");
                if (toggleonimg && toggleoffimg) {
                    if (on == 1) {
                        toggleonimg.style.display='inline';
                        toggleoffimg.style.display = 'none';
                    }
                    else {
                        toggleonimg.style.display='none';
                        toggleoffimg.style.display = 'inline';
                    }
                }
            }
        else if (XMLHttpRequestObject.readyState == 4 &&
                 XMLHttpRequestObject.status == 403) {
                    top.location.reload();
                }
    }
    XMLHttpRequestObject.send(null);

}
// empty function --- called from shared javascript
function IGEInitializeNotesAndComments(note) 
{
}
