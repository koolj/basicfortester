     // find the function (in the left hand nav whereever it is) and call it
     function walkHit(dir,nextChunk) {
       //Fix for defect #195790
       var contentframe = null;
       contentframe = SetContentFrame();
       if (contentframe == null) {
          nextHit(dir,true);
       }
       else {
          contentframe.nextHit(dir,true);  // may not have finished loading
       }
     }

