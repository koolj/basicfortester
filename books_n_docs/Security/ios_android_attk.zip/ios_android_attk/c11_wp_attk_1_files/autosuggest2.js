
/**
 * An autosuggest textbox control.
 * @class
 * @scope public
 */
function AutoSuggestControl(oTextbox /*:HTMLInputElement*/, 
                            oProvider /*:SuggestionProvider*/) {
    
    /**
     * The currently selected suggestions.
     * @scope private
     */   
    this.cur /*:int*/ = -1;

    /**
     * The dropdown list layer.
     * @scope private
     */
    this.layer = null;
    this.iframe = null;
    this.suggestions = null;  // these are the actual suggestions.  a nested div
    
    /**
     * Suggestion provider for the autosuggest feature.
     * @scope private.
     */
    this.provider /*:SuggestionProvider*/ = oProvider;
    
    /**
     * The textbox to capture.
     * @scope private
     */
    this.textbox /*:HTMLInputElement*/ = oTextbox;
    
    //initialize the control
    this.init();
    
}

/**
 * Autosuggests one or more suggestions for what the user has typed.
 * If no suggestions are passed in, then no autosuggest occurs.
 * @scope private
 * @param aSuggestions An array of suggestion strings.
 * @param bTypeAhead If the control should provide a type ahead suggestion.
 */
AutoSuggestControl.prototype.autosuggest = function (aSuggestions /*:Array*/,
                                                     bTypeAhead /*:boolean*/) {
    
    //make sure there's at least one suggestion
    if (aSuggestions.length > 0) {
        if (bTypeAhead) {
            if (aSuggestions[0].indexOf('^') != -1) {
                this.typeAhead(aSuggestions[0].split('^')[0]);
            }
            else {
                this.typeAhead(aSuggestions[0]);
            }
        }
        
        this.showSuggestions(aSuggestions);
    } else {
        this.hideSuggestions();
    }
};

/**
 * Creates the dropdown layer to display multiple suggestions.
 * @scope private
 */
AutoSuggestControl.prototype.createDropDown = function() {

var oThis = this;
if (isIE6) {
    this.iframe = document.createElement("iframe");
    this.iframe.style.position = "absolute";
    this.iframe.style.display = "none";
    this.iframe.style.width = this.textbox.offsetWidth;
    this.iframe.style.zindex = 1000;
    this.iframe.style.opacity = 0;
    document.body.appendChild(this.iframe);
  }

  //create the layer and assign styles
  this.layer = document.createElement("div");
  this.layer.className = "suggestions";
  this.layer.style.display = "none";
  this.layer.style.width = this.textbox.offsetWidth;
  this.layer.innerHTML = "<div class='b24-autosuggesttitle'>Search Hints...</div>";  //clear contents of the layer
  this.suggestions = document.createElement("div");  // add the actual suggestions text
  this.layer.appendChild(this.suggestions);

  //when the user clicks on the a suggestion, get the text (innerHTML)
  //and place it into a textbox
  this.layer.onmouseout = function(oEvent) {
    oThis.textbox.focus();
  }
  this.layer.onmousedown =
  this.layer.onmouseup =
  this.layer.onmouseover = function(oEvent) {
  oEvent = oEvent || window.event;
  oTarget = oEvent.target || oEvent.srcElement;

      if (oEvent.type == "mousedown") {
        oThis.textbox.value = oTarget.firstChild.nodeValue;
        oThis.hideSuggestions();
        oThis.textbox.focus();
      } else if (oEvent.type == "mouseover") {
        oThis.highlightSuggestion(oTarget);
      } else {
        oThis.textbox.focus();
      }
    };


  document.body.appendChild(this.layer);
};

/**
 * Gets the left coordinate of the textbox.
 * @scope private
 * @return The left coordinate of the textbox in pixels.
 */
AutoSuggestControl.prototype.getLeft = function () /*:int*/ {

    var oNode = this.textbox;
    var iLeft = 0;
    
    while(oNode.tagName.toLowerCase() != "body") {
        iLeft += oNode.offsetLeft;
        oNode = oNode.offsetParent;        
    }
    
    return iLeft;
};

/**
 * Gets the top coordinate of the textbox.
 * @scope private
 * @return The top coordinate of the textbox in pixels.
 */
AutoSuggestControl.prototype.getTop = function () /*:int*/ {

    var oNode = this.textbox;
    var iTop = 0;
    
    while(oNode.tagName.toLowerCase() != "body") {
        iTop += oNode.offsetTop;
        oNode = oNode.offsetParent;
    }
    
    return iTop;
};

/**
 * Handles three keydown events.
 * @scope private
 * @param oEvent The event object for the keydown event.
 */
AutoSuggestControl.prototype.handleKeyDown = function (oEvent /*:Event*/) {

    switch(oEvent.keyCode) {
        case 38: //up arrow
            this.previousSuggestion();
            break;
        case 40: //down arrow 
            this.nextSuggestion();
            break;
        case 13: //enter
            this.hideSuggestions();
            break;
    }

};

/**
 * Handles keyup events.
 * @scope private
 * @param oEvent The event object for the keyup event.
 */
AutoSuggestControl.prototype.handleKeyUp = function (oEvent /*:Event*/) {

    var iKeyCode = oEvent.keyCode;

    //for backspace (8) and delete (46), shows suggestions without typeahead
    if (iKeyCode == 8 || iKeyCode == 46) {
        this.provider.requestSuggestions(this, false);
        
    //make sure not to interfere with non-character keys
    } else if (iKeyCode < 32 || (iKeyCode >= 33 && iKeyCode < 46) || (iKeyCode >= 112 && iKeyCode <= 123)) {
        //ignore
    } else {
        //request suggestions from the suggestion provider with typeahead
        this.provider.requestSuggestions(this, true);
    }
};

/**
 * Hides the suggestion dropdown.
 * @scope private
 */
AutoSuggestControl.prototype.hideSuggestions = function () {
    this.layer.style.display = "none";
    if (this.iframe) {
        this.iframe.style.display = "none";
        oThis.textbox.focus();
    }
};

/**
 * Highlights the given node in the suggestions dropdown.
 * @scope private
 * @param oSuggestionNode The node representing a suggestion in the dropdown.
 */
AutoSuggestControl.prototype.highlightSuggestion = function (oSuggestionNode) {
    
    for (var i=0; i < this.suggestions.childNodes.length; i++) {
        var oNode = this.suggestions.childNodes[i];
        if (oNode == oSuggestionNode) {
            oNode.oldClassName = oNode.className;  // save --- we're often titles, etc.
            oNode.className = "current"
        } else if (oNode.className == "current") {
            oNode.className = oNode.oldClassName;
        }
    }
};

/**
 * Initializes the textbox with event handlers for
 * auto suggest functionality.
 * @scope private
 */
AutoSuggestControl.prototype.init = function () {

    //save a reference to this object
    var oThis = this;
    
    //assign the onkeyup event handler
    this.textbox.onkeyup = function (oEvent) {
    
        //check for the proper location of the event object
        if (!oEvent) {
            oEvent = window.event;
        }    
        
        //call the handleKeyUp() method with the event object
        oThis.handleKeyUp(oEvent);
    };
    
    //assign onkeydown event handler
    this.textbox.onkeydown = function (oEvent) {
    
        //check for the proper location of the event object
        if (!oEvent) {
            oEvent = window.event;
        }    
        
        //call the handleKeyDown() method with the event object
        oThis.handleKeyDown(oEvent);
    };
    
    //assign onblur event handler (hides suggestions)    
    this.textbox.onblur = function () {
        oThis.hideSuggestions();
    };
    
    //create the suggestions dropdown
    this.createDropDown();
};

/**
 * Highlights the next suggestion in the dropdown and
 * places the suggestion into the textbox.
 * @scope private
 */
AutoSuggestControl.prototype.nextSuggestion = function () {
    var cSuggestionNodes = this.suggestions.childNodes;

    if (cSuggestionNodes.length > 0 && this.cur < cSuggestionNodes.length-1) {
        var oNode = cSuggestionNodes[++this.cur];
        this.highlightSuggestion(oNode);
        this.textbox.value = oNode.firstChild.nodeValue; 
    }
};

/**
 * Highlights the previous suggestion in the dropdown and
 * places the suggestion into the textbox.
 * @scope private
 */
AutoSuggestControl.prototype.previousSuggestion = function () {
    var cSuggestionNodes = this.suggestions.childNodes;

    if (cSuggestionNodes.length > 0 && this.cur > 0) {
        var oNode = cSuggestionNodes[--this.cur];
        this.highlightSuggestion(oNode);
        this.textbox.value = oNode.firstChild.nodeValue;   
    }
};

/**
 * Selects a range of text in the textbox.
 * @scope public
 * @param iStart The start index (base 0) of the selection.
 * @param iLength The number of characters to select.
 */
AutoSuggestControl.prototype.selectRange = function (iStart /*:int*/, iLength /*:int*/) {

    //use text ranges for Internet Explorer
    if (this.textbox.createTextRange) {
        var oRange = this.textbox.createTextRange(); 
        oRange.moveStart("character", iStart); 
        oRange.moveEnd("character", iLength - this.textbox.value.length);      
        oRange.select();
        
    //use setSelectionRange() for Mozilla
    } else if (this.textbox.setSelectionRange) {
        this.textbox.setSelectionRange(iStart, iLength);
    }     

    //set focus back to the textbox
    this.textbox.focus();      
}; 

/**
 * Builds the suggestion layer contents, moves it into position,
 * and displays the layer.
 * @scope private
 * @param aSuggestions An array of suggestions for the control.
 */
AutoSuggestControl.prototype.showSuggestions = function(aSuggestions /*:Array*/) {

  var oDiv = null;
  this.suggestions.innerHTML = "";  //clear contents of the layer

  var html = "";
  /*
  for (var i=0; i < aSuggestions.length; i++) {
  oDiv = document.createElement("div");
  var text = "";
  var type = "";
  if (aSuggestions[i].indexOf('^') != -1) {
  var bits = aSuggestions[i].split('^');
  text = bits[0];
  type = bits[1];
  if (type != "") {
  oDiv.className = "b24-autosuggest-" + type;
  }
  }
  else {
  text = aSuggestions[i];
  }
  oDiv.appendChild(document.createTextNode(text));
  this.suggestions.appendChild(oDiv);
  }
  */
  for (var i = 0; i < aSuggestions.length; i++) {
    var isDupe = false;
    for (var j = 0; j < i; j++) {
      var t1 = aSuggestions[j];
      var t2 = aSuggestions[i];
      if (t1 && t2) {
        var where = t1.indexOf('^');
        if (where != -1) {
          t1 = t1.substring(0, where);
        }
        var where = t2.indexOf('^');
        if (where != -1) {
          t2 = t2.substring(0, where);
        }
        if (t1.toLowerCase() == t2.toLowerCase()) {
          isDupe = true;
          break;
        }
      }
    }
    if (isDupe) {
      continue;
    }
    html += "<div";
    var text = "";
    var type = "";
    if (aSuggestions[i].indexOf('^') != -1) {
      var bits = aSuggestions[i].split('^');
      text = bits[0];
      var halfway = Math.floor(text.length / 2);
      if (halfway * 2 != text.length) {
        if (text[halfway] == ' ') {
          var left = text.substring(0, halfway);
          var right = text.substring(halfway + 1);
          if (left == right) {
            text = text.substring(0, halfway);
          }
        }
      }
      type = bits[1];
      if (type != "") {
        html += " class='b24-autosuggest-" + type + "'";
      }
    }
    else {
      text = aSuggestions[i];
      var halfway = Math.floor(text.length / 2);
      if (halfway * 2 != text.length) {
        if (text[halfway] == ' ') {
          var left = text.substring(0, halfway);
          var right = text.substring(halfway + 1);
          if (left == right) {
            text = text.substring(0, halfway);
          }
        }
      }
    }
    html += ">";
    html += text;
    html += "</div>";
  }
  var ietopoffset = 0;
  var ieleftoffest = 0;
  if (isIE) ietopoffset = 15;
  if (isIE) ieleftoffest = 5;
  this.suggestions.innerHTML = html;  //clear contents of the layer
  this.layer.style.left = this.getLeft() + ieleftoffest + "px";
  this.layer.style.top = (this.getTop() + this.textbox.offsetHeight + ietopoffset) + "px";
  this.layer.style.display = "";
  if (this.iframe) {
    this.iframe.style.left = this.getLeft() + "px";
    this.iframe.style.top = (this.getTop() + this.textbox.offsetHeight + ietopoffset) + "px";
    this.iframe.style.display = "";
    this.iframe.style.height = this.layer.offsetHeight + "px";
  }

};

/**
 * Inserts a suggestion into the textbox, highlighting the 
 * suggested part of the text.
 * @scope private
 * @param sSuggestion The suggestion for the textbox.
 */
AutoSuggestControl.prototype.typeAhead = function (sSuggestion /*:String*/) {

    //check for support of typeahead functionality
    if (this.textbox.createTextRange || this.textbox.setSelectionRange){
// uncomment if you want the annoying autocomplete feature
//        var iLen = this.textbox.value.length; 
//        this.textbox.value = sSuggestion; 
//        this.selectRange(iLen, sSuggestion.length);
    }
};

