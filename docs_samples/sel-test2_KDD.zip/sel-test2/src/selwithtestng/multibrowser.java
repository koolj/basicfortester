package selwithtestng;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
 
public class multibrowser {
 
	public WebDriver driver;
	@Parameters("browser")
	@BeforeTest
	 
	//Passing Browser parameter from TestNG xml
	public void beforeTest(String browser) {
	 
		// If the browser is Firefox, then do this
		if(browser.equalsIgnoreCase("firefox")) {
			//System.setProperty("webdriver.firefox.driver", "D:\ToolsQA\OnlineStore\drivers\IEDriverServer.exe");
			//driver = new MarionetteDriver();
			driver = new FirefoxDriver();
		 
		// If browser is Safari, then do this	  
		}
		else if (browser.equalsIgnoreCase("safari")) { 
			driver = new SafariDriver();
		} 
		 
		// Doesn't the browser type, lauch the Website
		driver.get("http://www.store.demoqa.com"); 
	}
/*
	// Once Before method is completed, Test method will start
	@Test public void loginFailed() throws InterruptedException {
		driver.findElement(By.xpath(".//*[@id='account']/a")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("log")).sendKeys("testuser_1");
		driver.findElement(By.id("pwd")).sendKeys("Test@123");
		driver.findElement(By.id("login")).click();
		Thread.sleep(2000);
		WebElement element = driver.findElement(By.xpath("//form[@id='ajax_loginform']/p"));
		String strng = element.getText();
		Assert.assertEquals("ERROR: Invalid login credentials.", strng);

	}
*/	
	@Test
	public void runKDD() throws InterruptedException
	{
		
		//Call config CSV file
		KoolJ_datadriven KJdriven=new KoolJ_datadriven();
		KJdriven.openconfig("config.xls", driver);
	}
	@AfterTest public void afterTest() {
		driver.quit();
	}
}